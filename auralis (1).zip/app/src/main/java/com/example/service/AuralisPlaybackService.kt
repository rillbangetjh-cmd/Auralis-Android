package com.example.service

import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.AuralisApplication

class AuralisPlaybackService : MediaSessionService() {

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        val app = application as? AuralisApplication
        return app?.playerController?.mediaSession
    }
}
