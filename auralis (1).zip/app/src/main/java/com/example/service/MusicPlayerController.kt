package com.example.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import com.example.MainActivity
import com.example.data.model.EqualizerConfig
import com.example.data.model.RepeatMode
import com.example.data.model.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MusicPlayerController(
    private val context: Context,
    private val appScope: CoroutineScope,
    private val onTrackPlayed: (Track) -> Unit
) {
    private val renderersFactory = DefaultRenderersFactory(context)
        .setEnableDecoderFallback(true)

    val player: ExoPlayer = ExoPlayer.Builder(context, renderersFactory)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build(),
            true
        )
        .setHandleAudioBecomingNoisy(true)
        .build()

    val mediaSession: MediaSession = run {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        MediaSession.Builder(context, player)
            .setSessionActivity(pendingIntent)
            .build()
    }

    // Observables
    private val _currentTrack = MutableStateFlow<Track?>(null)
    val currentTrack: StateFlow<Track?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _bufferedPositionMs = MutableStateFlow(0L)
    val bufferedPositionMs: StateFlow<Long> = _bufferedPositionMs.asStateFlow()

    private val _queue = MutableStateFlow<List<Track>>(emptyList())
    val queue: StateFlow<List<Track>> = _queue.asStateFlow()

    private val _queueIndex = MutableStateFlow(-1)
    val queueIndex: StateFlow<Int> = _queueIndex.asStateFlow()

    private val _repeatMode = MutableStateFlow(RepeatMode.OFF)
    val repeatMode: StateFlow<RepeatMode> = _repeatMode.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _sleepTimerSeconds = MutableStateFlow<Int?>(null)
    val sleepTimerSeconds: StateFlow<Int?> = _sleepTimerSeconds.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var positionTrackerJob: Job? = null
    private var sleepTimerJob: Job? = null

    // System Hardware Equalizer (initialized lazily only when needed and playback active)
    private var systemEqualizer: Equalizer? = null
    private var systemBassBoost: BassBoost? = null

    init {
        setupPlayerListener()
        startPositionTracker()
    }

    private fun setupPlayerListener() {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                _isPlaying.value = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> {
                        _durationMs.value = player.duration.coerceAtLeast(0L)
                        _currentPositionMs.value = player.currentPosition.coerceAtLeast(0L)
                        _bufferedPositionMs.value = player.bufferedPosition.coerceAtLeast(0L)
                    }
                    Player.STATE_ENDED -> {
                        handleTrackEnded()
                    }
                    Player.STATE_IDLE, Player.STATE_BUFFERING -> {}
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                _errorMessage.value = "Playback error: ${error.localizedMessage ?: "Unknown"}"
                // Graceful fallback to next track if available
                appScope.launch {
                    delay(1500)
                    if (_queue.value.isNotEmpty() && _queueIndex.value < _queue.value.size - 1) {
                        skipNext()
                    }
                }
            }
        })
    }

    private fun handleTrackEnded() {
        when (_repeatMode.value) {
            RepeatMode.ONE -> {
                seekTo(0)
                player.play()
            }
            RepeatMode.ALL -> {
                skipNext()
            }
            RepeatMode.OFF -> {
                if (_queueIndex.value < _queue.value.size - 1) {
                    skipNext()
                } else {
                    _isPlaying.value = false
                    seekTo(0)
                }
            }
        }
    }

    private fun startPositionTracker() {
        positionTrackerJob?.cancel()
        positionTrackerJob = appScope.launch(Dispatchers.Main) {
            while (isActive) {
                if (player.isPlaying) {
                    _currentPositionMs.value = player.currentPosition.coerceAtLeast(0L)
                    _bufferedPositionMs.value = player.bufferedPosition.coerceAtLeast(0L)
                    _durationMs.value = player.duration.coerceAtLeast(0L)
                }
                delay(300)
            }
        }
    }

    fun playTrack(track: Track, newQueue: List<Track>? = null) {
        val tracks = newQueue ?: if (_queue.value.contains(track)) _queue.value else listOf(track)
        _queue.value = tracks
        val index = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
        _queueIndex.value = index
        _currentTrack.value = track

        loadAndPlay(track)
        onTrackPlayed(track)
    }

    fun playQueue(tracks: List<Track>, startIndex: Int = 0) {
        if (tracks.isEmpty()) return
        _queue.value = tracks
        val index = startIndex.coerceIn(0, tracks.size - 1)
        _queueIndex.value = index
        val track = tracks[index]
        _currentTrack.value = track

        loadAndPlay(track)
        onTrackPlayed(track)
    }

    private fun loadAndPlay(track: Track) {
        try {
            val mediaItem = MediaItem.Builder()
                .setMediaId(track.id)
                .setUri(Uri.parse(track.audioUri))
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(track.title)
                        .setArtist(track.artist)
                        .setAlbumTitle(track.album)
                        .setArtworkUri(if (track.artworkUri.isNotEmpty()) Uri.parse(track.artworkUri) else null)
                        .build()
                )
                .build()

            player.setMediaItem(mediaItem)
            player.prepare()
            player.play()
            _isPlaying.value = true
            _durationMs.value = track.durationMs
            _currentPositionMs.value = 0L
            _errorMessage.value = null
        } catch (e: Exception) {
            _errorMessage.value = "Failed to load audio: ${e.message}"
        }
    }

    fun togglePlayPause() {
        if (player.isPlaying) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_IDLE && _currentTrack.value != null) {
                _currentTrack.value?.let { loadAndPlay(it) }
            } else {
                player.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        val safePos = positionMs.coerceIn(0L, durationMs.value.coerceAtLeast(1L))
        player.seekTo(safePos)
        _currentPositionMs.value = safePos
    }

    fun skipNext() {
        val q = _queue.value
        if (q.isEmpty()) return
        var nextIdx = _queueIndex.value + 1
        if (nextIdx >= q.size) {
            if (_repeatMode.value == RepeatMode.ALL) {
                nextIdx = 0
            } else {
                return
            }
        }
        _queueIndex.value = nextIdx
        val track = q[nextIdx]
        _currentTrack.value = track
        loadAndPlay(track)
        onTrackPlayed(track)
    }

    fun skipPrevious() {
        if (_currentPositionMs.value > 3000L) {
            seekTo(0)
            return
        }
        val q = _queue.value
        if (q.isEmpty()) return
        var prevIdx = _queueIndex.value - 1
        if (prevIdx < 0) {
            prevIdx = if (_repeatMode.value == RepeatMode.ALL) q.size - 1 else 0
        }
        _queueIndex.value = prevIdx
        val track = q[prevIdx]
        _currentTrack.value = track
        loadAndPlay(track)
        onTrackPlayed(track)
    }

    fun toggleShuffle() {
        val next = !_isShuffle.value
        _isShuffle.value = next
        if (next && _queue.value.isNotEmpty()) {
            val current = _currentTrack.value
            val shuffled = _queue.value.shuffled().toMutableList()
            if (current != null) {
                shuffled.remove(current)
                shuffled.add(0, current)
            }
            _queue.value = shuffled
            _queueIndex.value = 0
        }
    }

    fun toggleRepeat() {
        _repeatMode.value = when (_repeatMode.value) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
        player.setPlaybackSpeed(speed)
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerSeconds.value = null
            return
        }
        val totalSec = minutes * 60
        _sleepTimerSeconds.value = totalSec
        sleepTimerJob = appScope.launch(Dispatchers.Main) {
            var remaining = totalSec
            while (remaining > 0 && isActive) {
                delay(1000)
                remaining--
                _sleepTimerSeconds.value = remaining
            }
            if (remaining == 0) {
                player.pause()
                _isPlaying.value = false
                _sleepTimerSeconds.value = null
            }
        }
    }

    fun addToQueue(track: Track) {
        val currentQ = _queue.value.toMutableList()
        currentQ.add(track)
        _queue.value = currentQ
        if (_currentTrack.value == null) {
            playTrack(track)
        }
    }

    fun playNext(track: Track) {
        val currentQ = _queue.value.toMutableList()
        val insertIndex = (_queueIndex.value + 1).coerceAtMost(currentQ.size)
        currentQ.add(insertIndex, track)
        _queue.value = currentQ
    }

    fun removeFromQueue(index: Int) {
        val currentQ = _queue.value.toMutableList()
        if (index in currentQ.indices) {
            val removingCurrent = index == _queueIndex.value
            currentQ.removeAt(index)
            _queue.value = currentQ
            if (removingCurrent) {
                if (currentQ.isNotEmpty()) {
                    val nextIdx = index.coerceAtMost(currentQ.size - 1)
                    _queueIndex.value = nextIdx
                    playTrack(currentQ[nextIdx])
                } else {
                    player.stop()
                    _currentTrack.value = null
                    _isPlaying.value = false
                }
            } else if (index < _queueIndex.value) {
                _queueIndex.value = _queueIndex.value - 1
            }
        }
    }

    fun applyEqualizer(config: EqualizerConfig) {
        if (!config.isEnabled) {
            try {
                systemEqualizer?.enabled = false
                systemBassBoost?.enabled = false
            } catch (_: Throwable) {}
            return
        }

        try {
            val sessionId = player.audioSessionId
            if (sessionId != C.AUDIO_SESSION_ID_UNSET && sessionId != 0) {
                if (systemEqualizer == null) {
                    systemEqualizer = Equalizer(0, sessionId).apply { enabled = true }
                }
                if (systemBassBoost == null) {
                    systemBassBoost = BassBoost(0, sessionId).apply { enabled = true }
                }

                systemEqualizer?.let { eq ->
                    eq.enabled = true
                    val numBands = eq.numberOfBands.toInt()
                    for (i in 0 until numBands.coerceAtMost(config.bands.size)) {
                        val level = (config.bands[i] * 100).toShort().coerceIn(
                            eq.bandLevelRange[0],
                            eq.bandLevelRange[1]
                        )
                        eq.setBandLevel(i.toShort(), level)
                    }
                }
                systemBassBoost?.let { bb ->
                    bb.enabled = config.bassBoost > 0
                    if (bb.strengthSupported) {
                        val strength = (config.bassBoost * 10).toShort().coerceIn(0, 1000)
                        bb.setStrength(strength)
                    }
                }
            }
        } catch (_: Throwable) {
            // AudioFX not supported on device or emulator - handled gracefully
            try {
                systemEqualizer?.release()
                systemBassBoost?.release()
            } catch (_: Throwable) {}
            systemEqualizer = null
            systemBassBoost = null
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun release() {
        positionTrackerJob?.cancel()
        sleepTimerJob?.cancel()
        try {
            systemEqualizer?.release()
            systemBassBoost?.release()
        } catch (_: Throwable) {}
        try {
            mediaSession.release()
        } catch (_: Throwable) {}
        try {
            player.release()
        } catch (_: Throwable) {}
    }
}
