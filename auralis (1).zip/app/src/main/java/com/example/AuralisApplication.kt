package com.example

import android.app.Application
import com.example.data.local.AuralisDatabase
import com.example.data.repository.MusicRepository
import com.example.service.MusicPlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AuralisApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var database: AuralisDatabase
        private set

    lateinit var repository: MusicRepository
        private set

    lateinit var playerController: MusicPlayerController
        private set

    override fun onCreate() {
        super.onCreate()
        database = AuralisDatabase.getInstance(this)
        repository = MusicRepository(this, database.musicDao(), applicationScope)
        playerController = MusicPlayerController(this, applicationScope) { track ->
            applicationScope.launch {
                repository.recordPlayed(track)
            }
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        playerController.release()
    }
}
