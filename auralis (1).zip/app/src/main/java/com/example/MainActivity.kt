package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.DynamicAtmosphereBackground
import com.example.ui.navigation.AuralisAppScaffold
import com.example.ui.theme.AuralisTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val app = application as AuralisApplication
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return MainViewModel(app.repository, app.playerController) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
            val equalizerConfig by viewModel.equalizerConfig.collectAsStateWithLifecycle()
            val currentTrack by viewModel.currentTrack.collectAsStateWithLifecycle()
            val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
            val currentPositionMs by viewModel.currentPositionMs.collectAsStateWithLifecycle()
            val durationMs by viewModel.durationMs.collectAsStateWithLifecycle()
            val isShuffle by viewModel.isShuffle.collectAsStateWithLifecycle()
            val repeatMode by viewModel.repeatMode.collectAsStateWithLifecycle()
            val queue by viewModel.queue.collectAsStateWithLifecycle()
            val queueIndex by viewModel.queueIndex.collectAsStateWithLifecycle()
            val playbackSpeed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
            val sleepTimerSeconds by viewModel.sleepTimerSeconds.collectAsStateWithLifecycle()
            val isFavorite by viewModel.isCurrentTrackFavorite.collectAsStateWithLifecycle()

            val feedData by viewModel.feedData.collectAsStateWithLifecycle()
            val allTracks by viewModel.allTracks.collectAsStateWithLifecycle()
            val favoriteTracks by viewModel.favoriteTracks.collectAsStateWithLifecycle()
            val localTracks by viewModel.localTracks.collectAsStateWithLifecycle()
            val playlists by viewModel.playlists.collectAsStateWithLifecycle()

            AuralisTheme(userSettings = userSettings) {
                DynamicAtmosphereBackground(
                    artworkUri = currentTrack?.artworkUri,
                    modifier = Modifier.fillMaxSize()
                ) {
                    AuralisAppScaffold(
                        feedData = feedData,
                        allTracks = allTracks,
                        favoriteTracks = favoriteTracks,
                        localTracks = localTracks,
                        playlists = playlists,
                        currentTrack = currentTrack,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        isShuffle = isShuffle,
                        repeatMode = repeatMode,
                        isFavorite = isFavorite,
                        queue = queue,
                        queueIndex = queueIndex,
                        playbackSpeed = playbackSpeed,
                        sleepTimerSeconds = sleepTimerSeconds,
                        equalizerConfig = equalizerConfig,
                        userSettings = userSettings,
                        onTrackSelect = { track, q -> viewModel.playTrack(track, q) },
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSeek = { pos -> viewModel.seekTo(pos) },
                        onSkipNext = { viewModel.skipNext() },
                        onSkipPrevious = { viewModel.skipPrevious() },
                        onToggleShuffle = { viewModel.toggleShuffle() },
                        onToggleRepeat = { viewModel.toggleRepeat() },
                        onToggleFavorite = { viewModel.toggleFavorite() },
                        onSelectQueueIndex = { idx -> viewModel.selectQueueIndex(idx) },
                        onRemoveFromQueue = { idx -> viewModel.removeFromQueue(idx) },
                        onSpeedChange = { spd -> viewModel.setPlaybackSpeed(spd) },
                        onSleepTimerChange = { min -> viewModel.setSleepTimer(min) },
                        onEqualizerConfigChange = { cfg -> viewModel.updateEqualizer(cfg) },
                        onSettingsChange = { set -> viewModel.updateSettings(set) },
                        onSearch = { q, f -> viewModel.search(q, f) },
                        onScanLocalFiles = { viewModel.scanLocalFiles() },
                        onCreatePlaylist = { name -> viewModel.createPlaylist(name) },
                        onRenamePlaylist = { id, name -> viewModel.renamePlaylist(id, name) },
                        onDeletePlaylist = { id -> viewModel.deletePlaylist(id) },
                        onGetPlaylistTracks = { id -> viewModel.getPlaylistTracks(id) },
                        onAddTrackToPlaylist = { pl, tr -> viewModel.addTrackToPlaylist(pl, tr) },
                        onRemoveTrackFromPlaylist = { plId, trId -> viewModel.removeTrackFromPlaylist(plId, trId) }
                    )
                }
            }
        }
    }
}
