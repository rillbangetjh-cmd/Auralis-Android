package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EqualizerConfig
import com.example.data.model.EqualizerPreset
import com.example.ui.theme.LocalLiquidGlassStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    config: EqualizerConfig,
    onConfigChange: (EqualizerConfig) -> Unit,
    onDismiss: () -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val bandLabels = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = if (style.isDarkMode) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = null,
                        tint = style.primaryColor
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Auralis Equalizer",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (config.isEnabled) "ON" else "OFF",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (config.isEnabled) style.primaryColor else Color.Gray,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                    Switch(
                        checked = config.isEnabled,
                        onCheckedChange = { onConfigChange(config.copy(isEnabled = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = style.primaryColor,
                            checkedTrackColor = style.primaryColor.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.testTag("equalizer_switch")
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close",
                            tint = if (style.isDarkMode) Color.White else Color.DarkGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Presets Horizontal Row
            Text(
                text = "PRESETS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = style.primaryColor
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(EqualizerPreset.allPresets) { preset ->
                    val isSelected = config.currentPreset == preset.name
                    GlassChip(
                        text = preset.name,
                        isSelected = isSelected,
                        onClick = {
                            onConfigChange(
                                config.copy(
                                    currentPreset = preset.name,
                                    bands = preset.bands
                                )
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Band Sliders (Interactive Frequency sliders)
            Text(
                text = "FREQUENCY BANDS (-10 dB to +10 dB)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = style.primaryColor
            )
            Spacer(modifier = Modifier.height(12.dp))

            bandLabels.forEachIndexed { index, label ->
                val currentLevel = config.bands.getOrElse(index) { 0 }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = label,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.8f) else Color.DarkGray,
                        modifier = Modifier.width(65.dp)
                    )
                    Slider(
                        value = currentLevel.toFloat(),
                        onValueChange = { newVal ->
                            val updatedBands = config.bands.toMutableList()
                            while (updatedBands.size <= index) updatedBands.add(0)
                            updatedBands[index] = newVal.toInt()
                            onConfigChange(
                                config.copy(
                                    currentPreset = "Custom",
                                    bands = updatedBands
                                )
                            )
                        },
                        valueRange = -10f..10f,
                        steps = 20,
                        enabled = config.isEnabled,
                        colors = SliderDefaults.colors(
                            thumbColor = style.primaryColor,
                            activeTrackColor = style.primaryColor,
                            inactiveTrackColor = style.glassBorder
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${if (currentLevel > 0) "+" else ""}$currentLevel dB",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentLevel != 0) style.primaryColor else Color.Gray,
                        modifier = Modifier.width(50.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Bass Boost & Treble Controls
            GlassBox(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ENHANCEMENTS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = style.primaryColor
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Bass Boost
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Bass Boost",
                            fontSize = 13.sp,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                            modifier = Modifier.width(85.dp)
                        )
                        Slider(
                            value = config.bassBoost.toFloat(),
                            onValueChange = { onConfigChange(config.copy(bassBoost = it.toInt())) },
                            valueRange = 0f..100f,
                            enabled = config.isEnabled,
                            colors = SliderDefaults.colors(
                                thumbColor = style.secondaryColor,
                                activeTrackColor = style.secondaryColor,
                                inactiveTrackColor = style.glassBorder
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${config.bassBoost}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = style.secondaryColor,
                            modifier = Modifier.width(42.dp)
                        )
                    }

                    // Treble
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Treble",
                            fontSize = 13.sp,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                            modifier = Modifier.width(85.dp)
                        )
                        Slider(
                            value = config.treble.toFloat(),
                            onValueChange = { onConfigChange(config.copy(treble = it.toInt())) },
                            valueRange = 0f..100f,
                            enabled = config.isEnabled,
                            colors = SliderDefaults.colors(
                                thumbColor = style.accentColor,
                                activeTrackColor = style.accentColor,
                                inactiveTrackColor = style.glassBorder
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${config.treble}%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = style.accentColor,
                            modifier = Modifier.width(42.dp)
                        )
                    }

                    // Preamp
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Preamp",
                            fontSize = 13.sp,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                            modifier = Modifier.width(85.dp)
                        )
                        Slider(
                            value = config.preampDb,
                            onValueChange = { onConfigChange(config.copy(preampDb = it)) },
                            valueRange = -6f..6f,
                            steps = 12,
                            enabled = config.isEnabled,
                            colors = SliderDefaults.colors(
                                thumbColor = style.primaryColor,
                                activeTrackColor = style.primaryColor,
                                inactiveTrackColor = style.glassBorder
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${if (config.preampDb > 0) "+" else ""}${config.preampDb.toInt()} dB",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = style.primaryColor,
                            modifier = Modifier.width(42.dp)
                        )
                    }
                }
            }
        }
    }
}
