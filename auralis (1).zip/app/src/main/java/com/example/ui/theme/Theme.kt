package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.data.model.BackgroundStyle
import com.example.data.model.LayoutDensity
import com.example.data.model.PlayerStyle
import com.example.data.model.ThemePreset
import com.example.data.model.UserSettings

@Immutable
data class LiquidGlassStyle(
    val primaryColor: Color,
    val secondaryColor: Color,
    val accentColor: Color,
    val glassOpacity: Float,
    val blurIntensity: Float,
    val cornerRadiusDp: Int,
    val backgroundStyle: BackgroundStyle,
    val isDarkMode: Boolean,
    val animationIntensity: Float,
    val layoutDensity: LayoutDensity,
    val playerStyle: PlayerStyle,
    val glassSurface: Color,
    val glassBorder: Color,
    val glassGlow: Color
)

val LocalLiquidGlassStyle = staticCompositionLocalOf {
    LiquidGlassStyle(
        primaryColor = AuroraPrimary,
        secondaryColor = AuroraSecondary,
        accentColor = AuroraAccent,
        glassOpacity = 0.28f,
        blurIntensity = 22f,
        cornerRadiusDp = 24,
        backgroundStyle = BackgroundStyle.DYNAMIC_ARTWORK,
        isDarkMode = true,
        animationIntensity = 1.0f,
        layoutDensity = LayoutDensity.COMFORTABLE,
        playerStyle = PlayerStyle.LIQUID_CARD,
        glassSurface = Color(0x331E293B),
        glassBorder = Color(0x28FFFFFF),
        glassGlow = AuroraPrimary.copy(alpha = 0.3f)
    )
}

@Composable
fun AuralisTheme(
    userSettings: UserSettings = UserSettings(),
    content: @Composable () -> Unit
) {
    val preset = userSettings.themePreset
    val primary = Color(preset.primaryColorHex)
    val secondary = Color(preset.secondaryColorHex)
    val accent = Color(preset.accentColorHex)

    val isDark = userSettings.isDarkMode

    val glassSurface = if (isDark) {
        Color(0xFF0F172A).copy(alpha = userSettings.glassOpacity.coerceIn(0.1f, 0.9f))
    } else {
        Color(0xFFFFFFFF).copy(alpha = (userSettings.glassOpacity * 1.3f).coerceIn(0.2f, 0.95f))
    }

    val glassBorder = if (isDark) {
        Color(0xFFFFFFFF).copy(alpha = (0.12f + userSettings.glassOpacity * 0.15f).coerceIn(0.1f, 0.35f))
    } else {
        primary.copy(alpha = 0.25f)
    }

    val glassGlow = primary.copy(alpha = 0.25f)

    val liquidGlassStyle = LiquidGlassStyle(
        primaryColor = primary,
        secondaryColor = secondary,
        accentColor = accent,
        glassOpacity = userSettings.glassOpacity,
        blurIntensity = userSettings.blurIntensity,
        cornerRadiusDp = userSettings.cornerRadiusDp,
        backgroundStyle = userSettings.backgroundStyle,
        isDarkMode = isDark,
        animationIntensity = userSettings.animationIntensity,
        layoutDensity = userSettings.layoutDensity,
        playerStyle = userSettings.playerStyle,
        glassSurface = glassSurface,
        glassBorder = glassBorder,
        glassGlow = glassGlow
    )

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = primary,
            secondary = secondary,
            tertiary = accent,
            background = DeepVoidDark,
            surface = DeepVoidDarkSecondary,
            onPrimary = Color.Black,
            onSecondary = Color.White,
            onBackground = Color(0xFFF1F5F9),
            onSurface = Color(0xFFF1F5F9)
        )
    } else {
        lightColorScheme(
            primary = primary,
            secondary = secondary,
            tertiary = accent,
            background = Color(0xFFF8FAFC),
            surface = Color(0xFFFFFFFF),
            onPrimary = Color.White,
            onSecondary = Color.White,
            onBackground = Color(0xFF0F172A),
            onSurface = Color(0xFF0F172A)
        )
    }

    CompositionLocalProvider(LocalLiquidGlassStyle provides liquidGlassStyle) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
