package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.data.repository.HomeFeedData
import com.example.ui.components.AudioQualityBadge
import com.example.ui.components.GlassBox
import com.example.ui.components.GlassChip
import com.example.ui.components.GlassIconButton
import com.example.ui.components.LiveVisualizerWaves
import com.example.ui.theme.LocalLiquidGlassStyle
import java.util.Calendar

@Composable
fun HomeScreen(
    feedData: HomeFeedData,
    currentTrack: Track?,
    isPlaying: Boolean,
    onTrackSelect: (Track, List<Track>) -> Unit,
    onTogglePlayPause: () -> Unit,
    onOpenNowPlaying: () -> Unit,
    onPlaylistSelect: (Playlist) -> Unit,
    modifier: Modifier = Modifier
) {
    val style = LocalLiquidGlassStyle.current
    var selectedMood by remember { mutableStateOf("All") }

    val moods = listOf(
        "All" to Icons.Filled.Headphones,
        "Energy" to Icons.Filled.ElectricBolt,
        "Focus" to Icons.Filled.GraphicEq,
        "Relax" to Icons.Filled.SelfImprovement,
        "Chill" to Icons.Filled.Nightlight
    )

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when (hour) {
            in 5..11 -> "Good Morning"
            in 12..16 -> "Good Afternoon"
            in 17..21 -> "Good Evening"
            else -> "Night Grooves"
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
        // 1. Header with greeting and glass avatar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "AURALIS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        color = style.primaryColor
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = greeting,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                }

                // Liquid Glass user avatar badge
                GlassBox(
                    modifier = Modifier.size(46.dp),
                    shape = CircleShape
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    listOf(style.primaryColor, style.secondaryColor)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "AU",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }
        }

        // 2. Large Now Playing Preview (if active)
        if (currentTrack != null) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                GlassBox(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clickable(onClick = onOpenNowPlaying),
                    shape = RoundedCornerShape(24.dp),
                    borderWidth = 1.2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = currentTrack.artworkUri,
                            contentDescription = currentTrack.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "NOW STREAMING",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = style.primaryColor
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                AudioQualityBadge(quality = currentTrack.audioQuality)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = currentTrack.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = currentTrack.artist,
                                fontSize = 13.sp,
                                color = if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        GlassIconButton(
                            icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play/Pause",
                            onClick = onTogglePlayPause,
                            size = 46.dp,
                            tint = style.primaryColor
                        )
                    }
                }
            }
        }

        // 3. Mood Chips Selector
        item {
            Spacer(modifier = Modifier.height(18.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(moods) { (mood, icon) ->
                    GlassChip(
                        text = mood,
                        isSelected = selectedMood == mood,
                        icon = icon,
                        onClick = { selectedMood = mood }
                    )
                }
            }
        }

        // 4. Quick Picks Horizontal Carousel
        item {
            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader(title = "Quick Picks", subtitle = "Handpicked for your frequency")
            Spacer(modifier = Modifier.height(12.dp))
            val displayedQuickPicks = if (selectedMood == "All") {
                feedData.quickPicks
            } else {
                feedData.trending.filter { it.genre.contains(selectedMood, true) }.ifEmpty { feedData.quickPicks }
            }

            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(displayedQuickPicks) { track ->
                    QuickPickCard(
                        track = track,
                        onClick = { onTrackSelect(track, displayedQuickPicks) }
                    )
                }
            }
        }

        // 5. Featured Playlists Carousel
        if (feedData.featuredPlaylists.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(28.dp))
                SectionHeader(title = "Liquid Playlists", subtitle = "Curated ambient & electronic journeys")
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(feedData.featuredPlaylists) { playlist ->
                        PlaylistCard(
                            playlist = playlist,
                            onClick = { onPlaylistSelect(playlist) }
                        )
                    }
                }
            }
        }

        // 6. Trending Audiophile Tracks
        item {
            Spacer(modifier = Modifier.height(28.dp))
            SectionHeader(title = "Trending Hi-Fi", subtitle = "Master quality & studio acoustic recordings")
            Spacer(modifier = Modifier.height(12.dp))
        }

        val allTrending = feedData.trending
        items(allTrending) { track ->
            val isCurrent = currentTrack?.id == track.id
            TrackListItem(
                track = track,
                isCurrent = isCurrent,
                isPlaying = isCurrent && isPlaying,
                onClick = { onTrackSelect(track, allTrending) },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    val style = LocalLiquidGlassStyle.current
    Column(modifier = Modifier.padding(horizontal = 20.dp)) {
        Text(
            text = title,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
        )
        Text(
            text = subtitle,
            fontSize = 12.sp,
            color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
        )
    }
}

@Composable
fun QuickPickCard(track: Track, onClick: () -> Unit) {
    val style = LocalLiquidGlassStyle.current
    GlassBox(
        modifier = Modifier
            .width(150.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(14.dp))
            ) {
                AsyncImage(
                    model = track.artworkUri,
                    contentDescription = track.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                ) {
                    AudioQualityBadge(quality = track.audioQuality)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = track.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = track.artist,
                fontSize = 12.sp,
                color = if (style.isDarkMode) Color.White.copy(alpha = 0.65f) else Color.Gray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PlaylistCard(playlist: Playlist, onClick: () -> Unit) {
    val style = LocalLiquidGlassStyle.current
    GlassBox(
        modifier = Modifier
            .width(200.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(14.dp))
            ) {
                AsyncImage(
                    model = playlist.artworkUri,
                    contentDescription = playlist.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                            )
                        )
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = playlist.name,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = playlist.description.ifEmpty { "${playlist.trackCount} tracks" },
                fontSize = 11.sp,
                color = if (style.isDarkMode) Color.White.copy(alpha = 0.65f) else Color.Gray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TrackListItem(
    track: Track,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailingAction: (@Composable () -> Unit)? = null
) {
    val style = LocalLiquidGlassStyle.current
    GlassBox(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        borderWidth = if (isCurrent) 1.5.dp else 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                AsyncImage(
                    model = track.artworkUri,
                    contentDescription = track.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                if (isPlaying) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        LiveVisualizerWaves(isPlaying = true, barCount = 3)
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    fontSize = 15.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.SemiBold,
                    color = if (isCurrent) style.primaryColor else if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = track.artist,
                        fontSize = 12.sp,
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.65f) else Color.DarkGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${track.durationFormatted}",
                        fontSize = 11.sp,
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.4f) else Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            AudioQualityBadge(quality = track.audioQuality)

            if (trailingAction != null) {
                Spacer(modifier = Modifier.width(4.dp))
                trailingAction()
            }
        }
    }
}
