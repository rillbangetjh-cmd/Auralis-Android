package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.EqualizerConfig
import com.example.data.model.Playlist
import com.example.data.model.RepeatMode
import com.example.data.model.Track
import com.example.data.model.UserSettings
import com.example.data.provider.SearchFilter
import com.example.data.provider.SearchResult
import com.example.data.repository.HomeFeedData
import com.example.data.repository.MusicRepository
import com.example.service.MusicPlayerController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: MusicRepository,
    private val playerController: MusicPlayerController
) : ViewModel() {

    val userSettings: StateFlow<UserSettings> = repository.userSettings
    val equalizerConfig: StateFlow<EqualizerConfig> = repository.equalizerConfig

    // Playback state from PlayerController
    val currentTrack: StateFlow<Track?> = playerController.currentTrack
    val isPlaying: StateFlow<Boolean> = playerController.isPlaying
    val currentPositionMs: StateFlow<Long> = playerController.currentPositionMs
    val durationMs: StateFlow<Long> = playerController.durationMs
    val isShuffle: StateFlow<Boolean> = playerController.isShuffle
    val repeatMode: StateFlow<RepeatMode> = playerController.repeatMode
    val queue: StateFlow<List<Track>> = playerController.queue
    val queueIndex: StateFlow<Int> = playerController.queueIndex
    val playbackSpeed: StateFlow<Float> = playerController.playbackSpeed
    val sleepTimerSeconds: StateFlow<Int?> = playerController.sleepTimerSeconds

    // Feeds and lists
    private val _feedData = MutableStateFlow(HomeFeedData())
    val feedData: StateFlow<HomeFeedData> = _feedData.asStateFlow()

    private val _allTracks = MutableStateFlow<List<Track>>(emptyList())
    val allTracks: StateFlow<List<Track>> = _allTracks.asStateFlow()

    private val _favoriteTracks = MutableStateFlow<List<Track>>(emptyList())
    val favoriteTracks: StateFlow<List<Track>> = _favoriteTracks.asStateFlow()

    private val _localTracks = MutableStateFlow<List<Track>>(emptyList())
    val localTracks: StateFlow<List<Track>> = _localTracks.asStateFlow()

    val playlists: StateFlow<List<Playlist>> = repository.playlists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isCurrentTrackFavorite: StateFlow<Boolean> = combine(
        currentTrack,
        repository.favoriteTrackIds
    ) { track, favIds ->
        track != null && favIds.contains(track.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    init {
        refreshData()
    }

    fun refreshData() {
        viewModelScope.launch {
            val feed = repository.getHomeFeed()
            _feedData.value = feed
            val all = repository.getAllLibraryTracks()
            _allTracks.value = all
            _localTracks.value = feed.localTracks
            _favoriteTracks.value = repository.getFavoriteTracks()
        }
    }

    fun playTrack(track: Track, newQueue: List<Track>) {
        playerController.playTrack(track, newQueue)
    }

    fun togglePlayPause() {
        playerController.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        playerController.seekTo(positionMs)
    }

    fun skipNext() {
        playerController.skipNext()
    }

    fun skipPrevious() {
        playerController.skipPrevious()
    }

    fun toggleShuffle() {
        playerController.toggleShuffle()
    }

    fun toggleRepeat() {
        playerController.toggleRepeat()
    }

    fun toggleFavorite(track: Track? = currentTrack.value) {
        if (track == null) return
        viewModelScope.launch {
            repository.toggleFavorite(track)
            _favoriteTracks.value = repository.getFavoriteTracks()
        }
    }

    fun selectQueueIndex(index: Int) {
        val q = queue.value
        if (index in q.indices) {
            playerController.playTrack(q[index], q)
        }
    }

    fun removeFromQueue(index: Int) {
        playerController.removeFromQueue(index)
    }

    fun setPlaybackSpeed(speed: Float) {
        playerController.setPlaybackSpeed(speed)
    }

    fun setSleepTimer(minutes: Int) {
        playerController.setSleepTimer(minutes)
    }

    fun updateEqualizer(config: EqualizerConfig) {
        repository.updateEqualizer(config)
        playerController.applyEqualizer(config)
    }

    fun updateSettings(settings: UserSettings) {
        repository.updateSettings(settings)
    }

    suspend fun search(query: String, filter: SearchFilter): SearchResult {
        return repository.search(query, filter)
    }

    suspend fun scanLocalFiles() {
        val local = repository.localProvider.scanLocalTracks()
        _localTracks.value = local
        val all = repository.getAllLibraryTracks()
        _allTracks.value = all
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name, initialTrack = currentTrack.value)
        }
    }

    fun renamePlaylist(id: Long, newName: String) {
        viewModelScope.launch {
            repository.renamePlaylist(id, newName, "")
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(id)
        }
    }

    fun getPlaylistTracks(playlistId: Long) = repository.getPlaylistTracks(playlistId)

    fun addTrackToPlaylist(playlist: Playlist, track: Track) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlist.id, track)
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackId: String) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }
}
