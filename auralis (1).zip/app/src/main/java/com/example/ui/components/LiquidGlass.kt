package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AudioQuality
import com.example.data.model.BackgroundStyle
import com.example.ui.theme.HiResBadgeBg
import com.example.ui.theme.HqBadgeBg
import com.example.ui.theme.LocalLiquidGlassStyle
import com.example.ui.theme.LosslessBadgeBg
import com.example.ui.theme.StandardBadgeBg

@Composable
fun GlassBox(
    modifier: Modifier = Modifier,
    shape: Shape? = null,
    borderWidth: Dp = 1.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val effectiveShape = shape ?: RoundedCornerShape(style.cornerRadiusDp.dp)

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            style.glassBorder,
            style.primaryColor.copy(alpha = 0.2f),
            style.glassBorder.copy(alpha = 0.05f)
        ),
        start = Offset(0f, 0f),
        end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
    )

    val clickableModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = ripple(color = style.primaryColor),
            onClick = onClick
        )
    } else Modifier

    Box(
        modifier = modifier
            .shadow(
                elevation = 6.dp,
                shape = effectiveShape,
                ambientColor = style.glassGlow,
                spotColor = style.glassGlow
            )
            .clip(effectiveShape)
            .background(style.glassSurface)
            .border(BorderStroke(borderWidth, borderBrush), effectiveShape)
            .then(clickableModifier),
        content = content
    )
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified,
    size: Dp = 48.dp,
    iconSize: Dp = 24.dp
) {
    val style = LocalLiquidGlassStyle.current
    val effectiveTint = if (tint == Color.Unspecified) {
        if (style.isDarkMode) Color.White else Color(0xFF0F172A)
    } else tint

    GlassBox(
        modifier = modifier.size(size),
        shape = CircleShape,
        onClick = onClick
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = effectiveTint,
            modifier = Modifier
                .size(iconSize)
                .align(Alignment.Center)
        )
    }
}

@Composable
fun GlassChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null
) {
    val style = LocalLiquidGlassStyle.current
    val bg = if (isSelected) {
        Brush.horizontalGradient(
            listOf(style.primaryColor.copy(alpha = 0.35f), style.secondaryColor.copy(alpha = 0.35f))
        )
    } else {
        Brush.horizontalGradient(listOf(style.glassSurface, style.glassSurface))
    }

    val border = if (isSelected) {
        style.primaryColor.copy(alpha = 0.8f)
    } else {
        style.glassBorder
    }

    Row(
        modifier = modifier
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, border, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = text,
            color = if (isSelected) {
                if (style.isDarkMode) Color.White else Color.Black
            } else {
                if (style.isDarkMode) Color.White.copy(alpha = 0.75f) else Color.DarkGray
            },
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

@Composable
fun AudioQualityBadge(
    quality: AudioQuality,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (quality) {
        AudioQuality.HI_RES -> HiResBadgeBg to Color.Black
        AudioQuality.LOSSLESS -> LosslessBadgeBg to Color.White
        AudioQuality.HIGH -> HqBadgeBg to Color.White
        AudioQuality.STANDARD -> StandardBadgeBg to Color.White
        AudioQuality.AUTO -> Color.DarkGray to Color.White
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor.copy(alpha = 0.85f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = quality.badge,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp
        )
    }
}

@Composable
fun DynamicAtmosphereBackground(
    artworkUri: String?,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val infiniteTransition = rememberInfiniteTransition(label = "ambient_liquid")

    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 18000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ambient_liquid_float"
    )

    Box(modifier = modifier.fillMaxSize()) {
        // Base dark backdrop
        val baseColor = if (style.isDarkMode) Color(0xFF070913) else Color(0xFFF1F5F9)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(baseColor)
        )

        when (style.backgroundStyle) {
            BackgroundStyle.DYNAMIC_ARTWORK -> {
                if (!artworkUri.isNullOrEmpty()) {
                    AsyncImage(
                        model = artworkUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .blur(radius = style.blurIntensity.coerceIn(12f, 50f).dp)
                    )
                    // Tint overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        baseColor.copy(alpha = 0.65f),
                                        baseColor.copy(alpha = 0.85f),
                                        baseColor
                                    )
                                )
                            )
                    )
                } else {
                    AuroraLiquidBackground(style, animProgress, baseColor)
                }
            }
            BackgroundStyle.AURORA_GRADIENT -> {
                AuroraLiquidBackground(style, animProgress, baseColor)
            }
            BackgroundStyle.DEEP_COSMIC -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    style.secondaryColor.copy(alpha = 0.25f),
                                    style.primaryColor.copy(alpha = 0.12f),
                                    baseColor
                                ),
                                center = Offset(300f + 200f * animProgress, 400f)
                            )
                        )
                )
            }
            BackgroundStyle.MINIMAL_DARK -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(baseColor)
                )
            }
        }

        // Foreground content inside the styled frame
        content()
    }
}

@Composable
private fun AuroraLiquidBackground(
    style: com.example.ui.theme.LiquidGlassStyle,
    animProgress: Float,
    baseColor: Color
) {
    val offset1 = Offset(200f + animProgress * 300f, 150f + animProgress * 200f)
    val offset2 = Offset(700f - animProgress * 200f, 900f - animProgress * 300f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        style.primaryColor.copy(alpha = 0.28f),
                        Color.Transparent
                    ),
                    center = offset1,
                    radius = 650f
                )
            )
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        style.secondaryColor.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = offset2,
                    radius = 750f
                )
            )
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.Transparent,
                        baseColor.copy(alpha = 0.4f),
                        baseColor.copy(alpha = 0.85f)
                    )
                )
            )
    )
}

@Composable
fun LiveVisualizerWaves(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barCount: Int = 4,
    barColor: Color = LocalLiquidGlassStyle.current.primaryColor
) {
    val transition = rememberInfiniteTransition(label = "visualizer")
    val h1 by transition.animateFloat(
        initialValue = 4f,
        targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "v1"
    )
    val h2 by transition.animateFloat(
        initialValue = 16f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(560, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "v2"
    )
    val h3 by transition.animateFloat(
        initialValue = 8f,
        targetValue = 22f,
        animationSpec = infiniteRepeatable(tween(380, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "v3"
    )
    val h4 by transition.animateFloat(
        initialValue = 14f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(tween(620, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "v4"
    )

    val heights = listOf(h1, h2, h3, h4)

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Bottom
    ) {
        for (i in 0 until barCount) {
            val barH = if (isPlaying) heights[i % heights.size] else 4f
            Box(
                modifier = Modifier
                    .padding(horizontal = 1.5.dp)
                    .width(3.dp)
                    .height(barH.dp)
                    .clip(RoundedCornerShape(1.5.dp))
                    .background(barColor)
            )
        }
    }
}

@Composable
fun InteractiveLiquidVinylDisc(
    artworkUri: String?,
    isPlaying: Boolean,
    rotationEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val style = LocalLiquidGlassStyle.current
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_spin")

    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    val currentRotation = if (isPlaying && rotationEnabled && style.animationIntensity > 0.1f) spinAngle else 0f

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .shadow(16.dp, CircleShape, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(CircleShape)
            .background(Color(0xFF0B0D13))
    ) {
        // Vinyl grooves and holographic sheen
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val centerOffset = center
            val radius = size.minDimension / 2f

            // Holographic rainbow reflection sheen
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        Color.Transparent,
                        style.primaryColor.copy(alpha = 0.15f),
                        Color.White.copy(alpha = 0.08f),
                        style.secondaryColor.copy(alpha = 0.18f),
                        Color.Transparent,
                        style.accentColor.copy(alpha = 0.15f),
                        Color.White.copy(alpha = 0.08f),
                        Color.Transparent
                    )
                ),
                radius = radius,
                center = centerOffset
            )

            // Concentric grooves
            val grooveCount = 14
            val step = (radius * 0.65f) / grooveCount
            for (i in 1..grooveCount) {
                val r = radius * 0.35f + i * step
                drawCircle(
                    color = Color.White.copy(alpha = if (i % 3 == 0) 0.06f else 0.025f),
                    radius = r,
                    center = centerOffset,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
                )
            }
        }

        // Center album label with spin motion
        Box(
            modifier = Modifier
                .size(72.dp)
                .align(Alignment.Center)
                .graphicsLayer(rotationZ = currentRotation)
                .clip(CircleShape)
                .background(Color.Black)
                .border(2.dp, Color.White.copy(alpha = 0.2f), CircleShape)
        ) {
            if (!artworkUri.isNullOrEmpty()) {
                AsyncImage(
                    model = artworkUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(style.primaryColor, style.secondaryColor)
                            )
                        )
                )
            }

            // Center spindle hole
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .align(Alignment.Center)
                    .clip(CircleShape)
                    .background(Color(0xFF0B0D13))
                    .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
            )
        }
    }
}
