package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudioQuality
import com.example.data.model.AudioSourceType
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.ui.components.AddToPlaylistSheet
import com.example.ui.components.GlassBox
import com.example.ui.components.GlassChip
import com.example.ui.theme.LocalLiquidGlassStyle
import kotlinx.coroutines.launch

enum class LibraryTab(val title: String) {
    ALL_SONGS("All Tracks"),
    FAVORITES("Favorites"),
    LOCAL_FILES("Device Storage"),
    ARTISTS("Artists"),
    ALBUMS("Albums")
}

enum class SortMode(val title: String) {
    TITLE("Title"),
    ARTIST("Artist"),
    DURATION("Duration"),
    QUALITY("Quality")
}

@Composable
fun LibraryScreen(
    tracks: List<Track>,
    favorites: List<Track>,
    localTracks: List<Track>,
    currentTrack: Track?,
    isPlaying: Boolean,
    onTrackSelect: (Track, List<Track>) -> Unit,
    onScanLocalFiles: suspend () -> Unit,
    playlists: List<Playlist>,
    onAddToPlaylist: (Playlist, Track) -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val style = LocalLiquidGlassStyle.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(LibraryTab.ALL_SONGS) }
    var sortMode by remember { mutableStateOf(SortMode.TITLE) }
    var isScanning by remember { mutableStateOf(false) }

    var trackToAddToPlaylist by remember { mutableStateOf<Track?>(null) }

    // Media permission launcher
    val permissionToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            scope.launch {
                isScanning = true
                onScanLocalFiles()
                isScanning = false
            }
        }
    }

    val currentList = when (selectedTab) {
        LibraryTab.ALL_SONGS -> tracks
        LibraryTab.FAVORITES -> favorites
        LibraryTab.LOCAL_FILES -> localTracks
        LibraryTab.ARTISTS, LibraryTab.ALBUMS -> tracks
    }

    val sortedList = remember(currentList, sortMode) {
        when (sortMode) {
            SortMode.TITLE -> currentList.sortedBy { it.title.lowercase() }
            SortMode.ARTIST -> currentList.sortedBy { it.artist.lowercase() }
            SortMode.DURATION -> currentList.sortedByDescending { it.durationMs }
            SortMode.QUALITY -> currentList.sortedByDescending { it.audioQuality.ordinal }
        }
    }

    // Hi-Fi Stats
    val hiResCount = currentList.count { it.audioQuality == AudioQuality.HI_RES }
    val losslessCount = currentList.count { it.audioQuality == AudioQuality.LOSSLESS }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 16.dp)
            .testTag("library_screen")
    ) {
        // Library Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Personal Library",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                )
                Text(
                    text = "${currentList.size} tracks available",
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                )
            }

            // Scan / Refresh Button
            Button(
                onClick = {
                    permissionLauncher.launch(permissionToRequest)
                },
                colors = ButtonDefaults.buttonColors(containerColor = style.primaryColor.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("scan_storage_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = "Scan",
                    tint = style.primaryColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isScanning) "Scanning..." else "Scan Device",
                    color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Hi-Fi Audio Stats Glass Card
        GlassBox(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatItem(label = "Total Tracks", value = "${tracks.size}")
                StatItem(label = "Hi-Res (24-bit)", value = "$hiResCount", highlight = style.primaryColor)
                StatItem(label = "Lossless (CD)", value = "$losslessCount", highlight = style.secondaryColor)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Library Navigation Tabs
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(LibraryTab.values()) { tab ->
                val icon = when (tab) {
                    LibraryTab.ALL_SONGS -> Icons.Filled.LibraryMusic
                    LibraryTab.FAVORITES -> Icons.Filled.Favorite
                    LibraryTab.LOCAL_FILES -> Icons.Filled.Folder
                    LibraryTab.ARTISTS -> Icons.Filled.Person
                    LibraryTab.ALBUMS -> Icons.Filled.Album
                }
                GlassChip(
                    text = tab.title,
                    isSelected = selectedTab == tab,
                    icon = icon,
                    onClick = { selectedTab = tab }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sort Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Sort,
                contentDescription = null,
                tint = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Sort by: ",
                fontSize = 12.sp,
                color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
            )
            SortMode.values().forEach { mode ->
                Text(
                    text = mode.title,
                    fontSize = 12.sp,
                    fontWeight = if (sortMode == mode) FontWeight.Bold else FontWeight.Normal,
                    color = if (sortMode == mode) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray,
                    modifier = Modifier
                        .clickable { sortMode = mode }
                        .padding(horizontal = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tracks List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            if (sortedList.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.MusicNote,
                                contentDescription = null,
                                tint = style.primaryColor.copy(alpha = 0.4f),
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = when (selectedTab) {
                                    LibraryTab.FAVORITES -> "No favorites added yet"
                                    LibraryTab.LOCAL_FILES -> "No local audio files found on device.\nTap 'Scan Device' to import."
                                    else -> "Library is empty"
                                },
                                fontSize = 14.sp,
                                color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                            )
                        }
                    }
                }
            } else {
                items(sortedList) { track ->
                    val isCurrent = currentTrack?.id == track.id
                    TrackListItem(
                        track = track,
                        isCurrent = isCurrent,
                        isPlaying = isCurrent && isPlaying,
                        onClick = { onTrackSelect(track, sortedList) },
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }

    trackToAddToPlaylist?.let { tr ->
        AddToPlaylistSheet(
            track = tr,
            playlists = playlists,
            onSelectPlaylist = { pl ->
                onAddToPlaylist(pl, tr)
                trackToAddToPlaylist = null
            },
            onCreateNewPlaylist = { name ->
                onCreateNewPlaylist(name)
                trackToAddToPlaylist = null
            },
            onDismiss = { trackToAddToPlaylist = null }
        )
    }
}

@Composable
private fun StatItem(label: String, value: String, highlight: Color? = null) {
    val style = LocalLiquidGlassStyle.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = highlight ?: (if (style.isDarkMode) Color.White else Color(0xFF0F172A))
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
        )
    }
}
