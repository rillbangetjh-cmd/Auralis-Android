package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AudioQuality
import com.example.data.model.Track
import com.example.ui.theme.LocalLiquidGlassStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioQualitySheet(
    track: Track,
    onDismiss: () -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = if (style.isDarkMode) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.HighQuality,
                        contentDescription = null,
                        tint = style.primaryColor
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Audio Quality & Stream Specs",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = if (style.isDarkMode) Color.White else Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            GlassBox(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Detected Tier",
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                            fontSize = 14.sp
                        )
                        AudioQualityBadge(quality = track.audioQuality)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    SpecRow("Codec", track.codec)
                    SpecRow("Container / Format", if (track.codec == "FLAC") "Native FLAC Audio" else "MPEG-4 / Audio Stream")
                    SpecRow("Bit Depth", "${track.bitDepth}-bit ${if (track.bitDepth >= 24) "(Studio Master)" else "(Standard CD)"}")
                    SpecRow("Sample Rate", "${track.sampleRateHz} Hz (${(track.sampleRateHz / 1000.0)} kHz)")
                    SpecRow("Bitrate", "${track.bitrateKbps} kbps")
                    SpecRow("Channels", if (track.channelCount == 2) "Stereo (2 Channels)" else "Mono (1 Channel)")
                    SpecRow("Source Type", track.sourceType.name)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Notice: Auralis adheres to strict audiophile standards. Lossless and Hi-Res labels are never faked or upscaled; they represent the genuine codec characteristics of the audio track.",
                fontSize = 11.sp,
                color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    val style = LocalLiquidGlassStyle.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = if (style.isDarkMode) Color.White.copy(alpha = 0.65f) else Color.DarkGray
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsSheet(
    track: Track,
    onDismiss: () -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = if (style.isDarkMode) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Lyrics,
                        contentDescription = null,
                        tint = style.primaryColor
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Lyrics - ${track.title}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = if (style.isDarkMode) Color.White else Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            GlassBox(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp),
                shape = RoundedCornerShape(20.dp)
            ) {
                if (!track.lyrics.isNullOrEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                            .verticalScroll(rememberScrollState()),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        track.lyrics.lines().forEach { line ->
                            val isTimestamp = line.startsWith("[") && line.contains("]")
                            val textOnly = if (isTimestamp) line.substringAfter("]").trim() else line.trim()
                            if (textOnly.isNotEmpty()) {
                                Text(
                                    text = textOnly,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center,
                                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.9f) else Color(0xFF0F172A),
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No legal lyrics available for this audio file.\nAuralis only displays legally sourced lyrics metadata.",
                            fontSize = 14.sp,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueSheet(
    queue: List<Track>,
    currentIndex: Int,
    onTrackSelect: (Int) -> Unit,
    onRemoveFromQueue: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = if (style.isDarkMode) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                        contentDescription = null,
                        tint = style.primaryColor
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Now Playing Queue (${queue.size})",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = if (style.isDarkMode) Color.White else Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (queue.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Queue is empty",
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(queue) { index, track ->
                        val isPlaying = index == currentIndex
                        GlassBox(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onTrackSelect(index) },
                            shape = RoundedCornerShape(14.dp),
                            borderWidth = if (isPlaying) 1.5.dp else 1.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPlaying) style.primaryColor else Color.Gray,
                                    modifier = Modifier.width(24.dp)
                                )
                                AsyncImage(
                                    model = track.artworkUri,
                                    contentDescription = null,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.title,
                                        fontSize = 14.sp,
                                        fontWeight = if (isPlaying) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isPlaying) style.primaryColor else if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                                        maxLines = 1
                                    )
                                    Text(
                                        text = track.artist,
                                        fontSize = 12.sp,
                                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.65f) else Color.Gray,
                                        maxLines = 1
                                    )
                                }
                                if (isPlaying) {
                                    LiveVisualizerWaves(isPlaying = true, barCount = 3)
                                }
                                IconButton(onClick = { onRemoveFromQueue(index) }) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = "Remove",
                                        tint = if (style.isDarkMode) Color.White.copy(alpha = 0.4f) else Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SleepSpeedSheet(
    playbackSpeed: Float,
    sleepTimerSeconds: Int?,
    onSpeedChange: (Float) -> Unit,
    onSleepTimerChange: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val speedOptions = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    val timerOptions = listOf(0, 15, 30, 45, 60)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = if (style.isDarkMode) Color(0xFF0F172A) else Color(0xFFF8FAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 36.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Timer,
                        contentDescription = null,
                        tint = style.primaryColor
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Playback & Sleep Timer",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = if (style.isDarkMode) Color.White else Color.DarkGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Playback Speed
            Text(
                text = "PLAYBACK SPEED",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = style.primaryColor
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                speedOptions.forEach { speed ->
                    GlassChip(
                        text = "${speed}x",
                        isSelected = playbackSpeed == speed,
                        onClick = { onSpeedChange(speed) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sleep Timer
            Text(
                text = "SLEEP TIMER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = style.primaryColor
            )
            if (sleepTimerSeconds != null) {
                val minLeft = sleepTimerSeconds / 60
                val secLeft = sleepTimerSeconds % 60
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Timer active: %d:%02d remaining".format(minLeft, secLeft),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = style.accentColor
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                timerOptions.forEach { minutes ->
                    val isSelected = if (minutes == 0) sleepTimerSeconds == null else false
                    GlassChip(
                        text = if (minutes == 0) "Off" else "${minutes}m",
                        isSelected = isSelected,
                        onClick = { onSleepTimerChange(minutes) }
                    )
                }
            }
        }
    }
}
