package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode as AnimRepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.EqualizerConfig
import com.example.data.model.Playlist
import com.example.data.model.RepeatMode
import com.example.data.model.Track
import com.example.ui.theme.LocalLiquidGlassStyle

@Composable
fun NowPlayingScreen(
    track: Track?,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    isShuffle: Boolean,
    repeatMode: RepeatMode,
    isFavorite: Boolean,
    queue: List<Track>,
    queueIndex: Int,
    playbackSpeed: Float,
    sleepTimerSeconds: Int?,
    equalizerConfig: EqualizerConfig,
    playlists: List<Playlist>,
    onTogglePlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onSelectQueueIndex: (Int) -> Unit,
    onRemoveFromQueue: (Int) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onSleepTimerChange: (Int) -> Unit,
    onEqualizerConfigChange: (EqualizerConfig) -> Unit,
    onAddToPlaylist: (Playlist) -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    onCollapse: () -> Unit,
    userSettings: com.example.data.model.UserSettings = com.example.data.model.UserSettings(),
    modifier: Modifier = Modifier
) {
    if (track == null) return
    val style = LocalLiquidGlassStyle.current

    var showQualitySheet by remember { mutableStateOf(false) }
    var showLyricsSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showSleepSpeedSheet by remember { mutableStateOf(false) }
    var showAddToPlaylistSheet by remember { mutableStateOf(false) }

    // Interactive 3D Parallax Tilt state
    var tiltX by remember { mutableFloatStateOf(0f) }
    var tiltY by remember { mutableFloatStateOf(0f) }
    val animTiltX by animateFloatAsState(
        targetValue = if (userSettings.parallaxTiltEnabled) tiltX else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "tilt_x"
    )
    val animTiltY by animateFloatAsState(
        targetValue = if (userSettings.parallaxTiltEnabled) tiltY else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 300f),
        label = "tilt_y"
    )

    // Vinyl slide out motion
    val vinylSlideOffset by animateDpAsState(
        targetValue = if (isPlaying && userSettings.vinylRotationEnabled && style.animationIntensity > 0.1f) 52.dp else 0.dp,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 220f),
        label = "vinyl_slide"
    )

    // Breathing pulse animation for album artwork
    val infiniteTransition = rememberInfiniteTransition(label = "now_playing_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = AnimRepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Scrubbing state
    var isDraggingSlider by remember { mutableStateOf(false) }
    var dragSliderPosition by remember { mutableFloatStateOf(0f) }

    val activePosition = if (isDraggingSlider) dragSliderPosition.toLong() else currentPositionMs
    val totalDuration = if (durationMs > 0) durationMs else track.durationMs

    DynamicAtmosphereBackground(
        artworkUri = track.artworkUri,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                GlassIconButton(
                    icon = Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Collapse Now Playing",
                    onClick = onCollapse,
                    size = 44.dp,
                    iconSize = 28.dp
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "PLAYING FROM",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp,
                        color = style.primaryColor
                    )
                    Text(
                        text = track.album.ifEmpty { "Auralis Library" },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.75f) else Color.DarkGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                GlassIconButton(
                    icon = Icons.Filled.MoreVert,
                    contentDescription = "More Options",
                    onClick = { showAddToPlaylistSheet = true },
                    size = 44.dp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Album Artwork with 3D Parallax Tilt & Vinyl Disc
            val artworkModifier = if (isPlaying && style.animationIntensity > 0.1f) {
                Modifier.scale(pulseScale)
            } else Modifier

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 380.dp)
                    .aspectRatio(1f)
                    .graphicsLayer {
                        rotationX = -animTiltY
                        rotationY = animTiltX
                        cameraDistance = 14f * density
                    }
                    .pointerInput(userSettings.parallaxTiltEnabled) {
                        if (userSettings.parallaxTiltEnabled) {
                            detectDragGestures(
                                onDrag = { _, dragAmount ->
                                    tiltX = (tiltX + dragAmount.x * 0.08f).coerceIn(-18f, 18f)
                                    tiltY = (tiltY + dragAmount.y * 0.08f).coerceIn(-18f, 18f)
                                },
                                onDragEnd = {
                                    tiltX = 0f
                                    tiltY = 0f
                                },
                                onDragCancel = {
                                    tiltX = 0f
                                    tiltY = 0f
                                }
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // Interactive Liquid Vinyl Disc sliding out from behind the cover
                if (userSettings.vinylRotationEnabled) {
                    InteractiveLiquidVinylDisc(
                        artworkUri = track.artworkUri,
                        isPlaying = isPlaying,
                        rotationEnabled = userSettings.vinylRotationEnabled,
                        modifier = Modifier
                            .fillMaxSize(0.92f)
                            .offset(x = vinylSlideOffset)
                    )
                }

                // Album Artwork Cover with Liquid Glass Border
                Box(
                    modifier = Modifier
                        .fillMaxSize(if (userSettings.vinylRotationEnabled && isPlaying) 0.90f else 0.98f)
                        .then(artworkModifier)
                        .shadow(
                            elevation = 20.dp,
                            shape = RoundedCornerShape(32.dp),
                            ambientColor = style.glassGlow,
                            spotColor = style.glassGlow
                        )
                        .clip(RoundedCornerShape(32.dp))
                        .background(style.glassSurface)
                ) {
                    if (track.artworkUri.isNotEmpty()) {
                        AsyncImage(
                            model = track.artworkUri,
                            contentDescription = track.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.linearGradient(
                                        listOf(style.primaryColor, style.secondaryColor)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.QueueMusic,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(80.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Title, Artist & Quality / Favorite Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = track.artist,
                        fontSize = 16.sp,
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Audio Quality & Favorite Button
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showQualitySheet = true }
                    ) {
                        AudioQualityBadge(quality = track.audioQuality)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(44.dp).testTag("now_playing_favorite_button")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = if (isFavorite) "In Favorites" else "Add to Favorites",
                            tint = if (isFavorite) Color(0xFFFF0055) else if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Progress Slider
            val progress = if (totalDuration > 0) {
                (activePosition.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f)
            } else 0f

            Slider(
                value = progress,
                onValueChange = { frac ->
                    isDraggingSlider = true
                    dragSliderPosition = frac * totalDuration
                },
                onValueChangeFinished = {
                    onSeek(dragSliderPosition.toLong())
                    isDraggingSlider = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = style.primaryColor,
                    activeTrackColor = style.primaryColor,
                    inactiveTrackColor = style.glassBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("now_playing_scrubber")
            )

            // Elapsed & Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(activePosition),
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                )
                Text(
                    text = formatMs(totalDuration),
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Main Playback Controls (Shuffle, Prev, Play/Pause, Next, Repeat)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Shuffle
                IconButton(
                    onClick = onToggleShuffle,
                    modifier = Modifier.size(48.dp).testTag("now_playing_shuffle")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.LightGray,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Previous
                IconButton(
                    onClick = onSkipPrevious,
                    modifier = Modifier.size(54.dp).testTag("now_playing_prev")
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipPrevious,
                        contentDescription = "Previous",
                        tint = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                        modifier = Modifier.size(34.dp)
                    )
                }

                // Play / Pause (Large Glowing Liquid Circle)
                GlassBox(
                    modifier = Modifier
                        .size(72.dp)
                        .testTag("now_playing_play_pause"),
                    shape = CircleShape,
                    borderWidth = 1.5.dp,
                    onClick = onTogglePlayPause
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.radialGradient(
                                    listOf(
                                        style.primaryColor.copy(alpha = 0.35f),
                                        style.secondaryColor.copy(alpha = 0.2f)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                // Next
                IconButton(
                    onClick = onSkipNext,
                    modifier = Modifier.size(54.dp).testTag("now_playing_next")
                ) {
                    Icon(
                        imageVector = Icons.Filled.SkipNext,
                        contentDescription = "Next",
                        tint = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                        modifier = Modifier.size(34.dp)
                    )
                }

                // Repeat
                IconButton(
                    onClick = onToggleRepeat,
                    modifier = Modifier.size(48.dp).testTag("now_playing_repeat")
                ) {
                    val (icon, tint) = when (repeatMode) {
                        RepeatMode.OFF -> Icons.Filled.Repeat to (if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.LightGray)
                        RepeatMode.ALL -> Icons.Filled.Repeat to style.primaryColor
                        RepeatMode.ONE -> Icons.Filled.RepeatOne to style.primaryColor
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = "Repeat",
                        tint = tint,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Liquid Glass Auxiliary Buttons (Lyrics, Queue, Equalizer, Sleep/Speed, Add to Playlist)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                GlassIconButton(
                    icon = Icons.Filled.Lyrics,
                    contentDescription = "Lyrics",
                    onClick = { showLyricsSheet = true },
                    size = 46.dp,
                    iconSize = 22.dp
                )

                GlassIconButton(
                    icon = Icons.AutoMirrored.Filled.QueueMusic,
                    contentDescription = "Queue",
                    onClick = { showQueueSheet = true },
                    size = 46.dp,
                    iconSize = 22.dp
                )

                GlassIconButton(
                    icon = Icons.Filled.Equalizer,
                    contentDescription = "Equalizer",
                    onClick = { showEqualizerSheet = true },
                    size = 46.dp,
                    iconSize = 22.dp
                )

                GlassIconButton(
                    icon = Icons.Filled.Timer,
                    contentDescription = "Sleep & Speed",
                    onClick = { showSleepSpeedSheet = true },
                    size = 46.dp,
                    iconSize = 22.dp,
                    tint = if (sleepTimerSeconds != null) style.accentColor else Color.Unspecified
                )

                GlassIconButton(
                    icon = Icons.Filled.PlaylistAdd,
                    contentDescription = "Add to Playlist",
                    onClick = { showAddToPlaylistSheet = true },
                    size = 46.dp,
                    iconSize = 22.dp
                )
            }

            Spacer(modifier = Modifier.height(36.dp))
        }
    }

    // Modal Sheets
    if (showQualitySheet) {
        AudioQualitySheet(track = track, onDismiss = { showQualitySheet = false })
    }
    if (showLyricsSheet) {
        LyricsSheet(track = track, onDismiss = { showLyricsSheet = false })
    }
    if (showQueueSheet) {
        QueueSheet(
            queue = queue,
            currentIndex = queueIndex,
            onTrackSelect = onSelectQueueIndex,
            onRemoveFromQueue = onRemoveFromQueue,
            onDismiss = { showQueueSheet = false }
        )
    }
    if (showEqualizerSheet) {
        EqualizerSheet(
            config = equalizerConfig,
            onConfigChange = onEqualizerConfigChange,
            onDismiss = { showEqualizerSheet = false }
        )
    }
    if (showSleepSpeedSheet) {
        SleepSpeedSheet(
            playbackSpeed = playbackSpeed,
            sleepTimerSeconds = sleepTimerSeconds,
            onSpeedChange = onSpeedChange,
            onSleepTimerChange = onSleepTimerChange,
            onDismiss = { showSleepSpeedSheet = false }
        )
    }
    if (showAddToPlaylistSheet) {
        AddToPlaylistSheet(
            track = track,
            playlists = playlists,
            onSelectPlaylist = onAddToPlaylist,
            onCreateNewPlaylist = onCreateNewPlaylist,
            onDismiss = { showAddToPlaylistSheet = false }
        )
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%d:%02d".format(minutes, seconds)
}
