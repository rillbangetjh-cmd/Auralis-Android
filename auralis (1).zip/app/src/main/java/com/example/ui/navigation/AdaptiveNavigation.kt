package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EqualizerConfig
import com.example.data.model.Playlist
import com.example.data.model.RepeatMode
import com.example.data.model.Track
import com.example.data.model.UserSettings
import com.example.data.provider.SearchFilter
import com.example.data.provider.SearchResult
import com.example.data.repository.HomeFeedData
import com.example.ui.components.EqualizerSheet
import com.example.ui.components.GlassBox
import com.example.ui.components.MiniPlayer
import com.example.ui.components.NowPlayingScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LocalLiquidGlassStyle
import kotlinx.coroutines.flow.Flow

enum class AppDestination(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    SEARCH("Search", Icons.Filled.Search),
    LIBRARY("Library", Icons.Filled.LibraryMusic),
    PLAYLISTS("Playlists", Icons.AutoMirrored.Filled.QueueMusic),
    SETTINGS("Settings", Icons.Filled.Settings)
}

@Composable
fun AuralisAppScaffold(
    feedData: HomeFeedData,
    allTracks: List<Track>,
    favoriteTracks: List<Track>,
    localTracks: List<Track>,
    playlists: List<Playlist>,
    currentTrack: Track?,
    isPlaying: Boolean,
    currentPositionMs: Long,
    durationMs: Long,
    isShuffle: Boolean,
    repeatMode: RepeatMode,
    isFavorite: Boolean,
    queue: List<Track>,
    queueIndex: Int,
    playbackSpeed: Float,
    sleepTimerSeconds: Int?,
    equalizerConfig: EqualizerConfig,
    userSettings: UserSettings,
    onTrackSelect: (Track, List<Track>) -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onToggleFavorite: () -> Unit,
    onSelectQueueIndex: (Int) -> Unit,
    onRemoveFromQueue: (Int) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onSleepTimerChange: (Int) -> Unit,
    onEqualizerConfigChange: (EqualizerConfig) -> Unit,
    onSettingsChange: (UserSettings) -> Unit,
    onSearch: suspend (String, SearchFilter) -> SearchResult,
    onScanLocalFiles: suspend () -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onGetPlaylistTracks: (Long) -> Flow<List<Track>>,
    onAddTrackToPlaylist: (Playlist, Track) -> Unit,
    onRemoveTrackFromPlaylist: (Long, String) -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    var currentDestination by remember { mutableStateOf(AppDestination.HOME) }
    var isNowPlayingExpanded by remember { mutableStateOf(false) }
    var showStandAloneEqualizer by remember { mutableStateOf(false) }

    // Navigation back stack handling
    BackHandler(enabled = isNowPlayingExpanded || currentDestination != AppDestination.HOME) {
        if (isNowPlayingExpanded) {
            isNowPlayingExpanded = false
        } else if (currentDestination != AppDestination.HOME) {
            currentDestination = AppDestination.HOME
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        if (isWideScreen) {
            // Tablet / Desktop layout with Navigation Rail on left
            Row(modifier = Modifier.fillMaxSize()) {
                GlassNavigationRail(
                    currentDestination = currentDestination,
                    onDestinationChange = { currentDestination = it },
                    modifier = Modifier.width(96.dp).fillMaxHeight()
                )

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    MainScreenContent(
                        destination = currentDestination,
                        feedData = feedData,
                        allTracks = allTracks,
                        favoriteTracks = favoriteTracks,
                        localTracks = localTracks,
                        playlists = playlists,
                        currentTrack = currentTrack,
                        isPlaying = isPlaying,
                        onTrackSelect = onTrackSelect,
                        onTogglePlayPause = onTogglePlayPause,
                        onOpenNowPlaying = { isNowPlayingExpanded = true },
                        onPlaylistSelect = {
                            currentDestination = AppDestination.PLAYLISTS
                        },
                        onSearch = onSearch,
                        onScanLocalFiles = onScanLocalFiles,
                        onCreatePlaylist = onCreatePlaylist,
                        onRenamePlaylist = onRenamePlaylist,
                        onDeletePlaylist = onDeletePlaylist,
                        onGetPlaylistTracks = onGetPlaylistTracks,
                        onAddTrackToPlaylist = onAddTrackToPlaylist,
                        onRemoveTrackFromPlaylist = onRemoveTrackFromPlaylist,
                        userSettings = userSettings,
                        onSettingsChange = onSettingsChange,
                        onOpenEqualizer = { showStandAloneEqualizer = true }
                    )

                    // Floating MiniPlayer at bottom of content
                    MiniPlayer(
                        currentTrack = currentTrack,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        onTogglePlayPause = onTogglePlayPause,
                        onSkipNext = onSkipNext,
                        onClick = { isNowPlayingExpanded = true },
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .navigationBarsPadding()
                            .padding(bottom = 12.dp)
                    )
                }
            }
        } else {
            // Phone portrait layout with Bottom Bar
            Box(modifier = Modifier.fillMaxSize()) {
                MainScreenContent(
                    destination = currentDestination,
                    feedData = feedData,
                    allTracks = allTracks,
                    favoriteTracks = favoriteTracks,
                    localTracks = localTracks,
                    playlists = playlists,
                    currentTrack = currentTrack,
                    isPlaying = isPlaying,
                    onTrackSelect = onTrackSelect,
                    onTogglePlayPause = onTogglePlayPause,
                    onOpenNowPlaying = { isNowPlayingExpanded = true },
                    onPlaylistSelect = {
                        currentDestination = AppDestination.PLAYLISTS
                    },
                    onSearch = onSearch,
                    onScanLocalFiles = onScanLocalFiles,
                    onCreatePlaylist = onCreatePlaylist,
                    onRenamePlaylist = onRenamePlaylist,
                    onDeletePlaylist = onDeletePlaylist,
                    onGetPlaylistTracks = onGetPlaylistTracks,
                    onAddTrackToPlaylist = onAddTrackToPlaylist,
                    onRemoveTrackFromPlaylist = onRemoveTrackFromPlaylist,
                    userSettings = userSettings,
                    onSettingsChange = onSettingsChange,
                    onOpenEqualizer = { showStandAloneEqualizer = true }
                )

                // Bottom floating components: MiniPlayer & Bottom Nav
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                ) {
                    MiniPlayer(
                        currentTrack = currentTrack,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        onTogglePlayPause = onTogglePlayPause,
                        onSkipNext = onSkipNext,
                        onClick = { isNowPlayingExpanded = true },
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    GlassBottomNavigationBar(
                        currentDestination = currentDestination,
                        onDestinationChange = { currentDestination = it }
                    )
                }
            }
        }

        // Fullscreen Immersive Now Playing Overlay
        AnimatedVisibility(
            visible = isNowPlayingExpanded && currentTrack != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            NowPlayingScreen(
                track = currentTrack,
                isPlaying = isPlaying,
                currentPositionMs = currentPositionMs,
                durationMs = durationMs,
                isShuffle = isShuffle,
                repeatMode = repeatMode,
                isFavorite = isFavorite,
                queue = queue,
                queueIndex = queueIndex,
                playbackSpeed = playbackSpeed,
                sleepTimerSeconds = sleepTimerSeconds,
                equalizerConfig = equalizerConfig,
                playlists = playlists,
                onTogglePlayPause = onTogglePlayPause,
                onSeek = onSeek,
                onSkipNext = onSkipNext,
                onSkipPrevious = onSkipPrevious,
                onToggleShuffle = onToggleShuffle,
                onToggleRepeat = onToggleRepeat,
                onToggleFavorite = onToggleFavorite,
                onSelectQueueIndex = onSelectQueueIndex,
                onRemoveFromQueue = onRemoveFromQueue,
                onSpeedChange = onSpeedChange,
                onSleepTimerChange = onSleepTimerChange,
                onEqualizerConfigChange = onEqualizerConfigChange,
                onAddToPlaylist = { pl -> currentTrack?.let { onAddTrackToPlaylist(pl, it) } },
                onCreateNewPlaylist = { name -> onCreatePlaylist(name) },
                onCollapse = { isNowPlayingExpanded = false },
                userSettings = userSettings
            )
        }

        // Standalone Equalizer sheet if triggered from settings
        if (showStandAloneEqualizer) {
            EqualizerSheet(
                config = equalizerConfig,
                onConfigChange = onEqualizerConfigChange,
                onDismiss = { showStandAloneEqualizer = false }
            )
        }
    }
}

@Composable
fun MainScreenContent(
    destination: AppDestination,
    feedData: HomeFeedData,
    allTracks: List<Track>,
    favoriteTracks: List<Track>,
    localTracks: List<Track>,
    playlists: List<Playlist>,
    currentTrack: Track?,
    isPlaying: Boolean,
    onTrackSelect: (Track, List<Track>) -> Unit,
    onTogglePlayPause: () -> Unit,
    onOpenNowPlaying: () -> Unit,
    onPlaylistSelect: (Playlist) -> Unit,
    onSearch: suspend (String, SearchFilter) -> SearchResult,
    onScanLocalFiles: suspend () -> Unit,
    onCreatePlaylist: (String) -> Unit,
    onRenamePlaylist: (Long, String) -> Unit,
    onDeletePlaylist: (Long) -> Unit,
    onGetPlaylistTracks: (Long) -> Flow<List<Track>>,
    onAddTrackToPlaylist: (Playlist, Track) -> Unit,
    onRemoveTrackFromPlaylist: (Long, String) -> Unit,
    userSettings: UserSettings,
    onSettingsChange: (UserSettings) -> Unit,
    onOpenEqualizer: () -> Unit
) {
    when (destination) {
        AppDestination.HOME -> HomeScreen(
            feedData = feedData,
            currentTrack = currentTrack,
            isPlaying = isPlaying,
            onTrackSelect = onTrackSelect,
            onTogglePlayPause = onTogglePlayPause,
            onOpenNowPlaying = onOpenNowPlaying,
            onPlaylistSelect = onPlaylistSelect
        )
        AppDestination.SEARCH -> SearchScreen(
            onSearch = onSearch,
            currentTrack = currentTrack,
            isPlaying = isPlaying,
            onTrackSelect = onTrackSelect,
            onPlaylistSelect = onPlaylistSelect,
            playlists = playlists,
            onAddToPlaylist = onAddTrackToPlaylist,
            onCreateNewPlaylist = onCreatePlaylist
        )
        AppDestination.LIBRARY -> LibraryScreen(
            tracks = allTracks,
            favorites = favoriteTracks,
            localTracks = localTracks,
            currentTrack = currentTrack,
            isPlaying = isPlaying,
            onTrackSelect = onTrackSelect,
            onScanLocalFiles = onScanLocalFiles,
            playlists = playlists,
            onAddToPlaylist = onAddTrackToPlaylist,
            onCreateNewPlaylist = onCreatePlaylist
        )
        AppDestination.PLAYLISTS -> PlaylistsScreen(
            playlists = playlists,
            onCreatePlaylist = onCreatePlaylist,
            onRenamePlaylist = onRenamePlaylist,
            onDeletePlaylist = onDeletePlaylist,
            onGetPlaylistTracks = onGetPlaylistTracks,
            onRemoveTrackFromPlaylist = onRemoveTrackFromPlaylist,
            currentTrack = currentTrack,
            isPlaying = isPlaying,
            onTrackSelect = onTrackSelect
        )
        AppDestination.SETTINGS -> SettingsScreen(
            userSettings = userSettings,
            onSettingsChange = onSettingsChange,
            onOpenEqualizer = onOpenEqualizer
        )
    }
}

@Composable
fun GlassBottomNavigationBar(
    currentDestination: AppDestination,
    onDestinationChange: (AppDestination) -> Unit
) {
    val style = LocalLiquidGlassStyle.current

    GlassBox(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("glass_bottom_bar"),
        shape = RoundedCornerShape(26.dp),
        borderWidth = 1.2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppDestination.values().forEach { dest ->
                val isSelected = currentDestination == dest
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onDestinationChange(dest) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = dest.icon,
                        contentDescription = dest.title,
                        tint = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.DarkGray,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = dest.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.DarkGray
                    )
                }
            }
        }
    }
}

@Composable
fun GlassNavigationRail(
    currentDestination: AppDestination,
    onDestinationChange: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val style = LocalLiquidGlassStyle.current

    GlassBox(
        modifier = modifier.padding(12.dp),
        shape = RoundedCornerShape(28.dp),
        borderWidth = 1.2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "AU",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = style.primaryColor
            )

            Spacer(modifier = Modifier.height(16.dp))

            AppDestination.values().forEach { dest ->
                val isSelected = currentDestination == dest
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onDestinationChange(dest) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = dest.icon,
                        contentDescription = dest.title,
                        tint = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.DarkGray,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = dest.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.DarkGray
                    )
                }
            }
        }
    }
}
