package com.example.ui.util

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import com.example.R

enum class AppIconOption(
    val id: String,
    val title: String,
    val subtitle: String,
    val aliasName: String?,
    val previewDrawableRes: Int
) {
    AURORA(
        id = "AURORA",
        title = "Aurora Prism",
        subtitle = "Electric Cyan & Emerald Glow (Default)",
        aliasName = null,
        previewDrawableRes = R.drawable.ic_launcher_fg
    ),
    MIDNIGHT(
        id = "MIDNIGHT",
        title = "Midnight Cyber",
        subtitle = "Deep Indigo & Electric Violet Crystal",
        aliasName = "com.example.MainActivityMidnight",
        previewDrawableRes = R.drawable.ic_icon_midnight_fg
    ),
    SUNSET(
        id = "SUNSET",
        title = "Sunset Solarium",
        subtitle = "Magenta Coral & Amber Hologram",
        aliasName = "com.example.MainActivitySunset",
        previewDrawableRes = R.drawable.ic_icon_sunset_fg
    )
}

object AppIconManager {

    fun setAppIcon(context: Context, option: AppIconOption) {
        val pm = context.packageManager
        val pkg = context.packageName

        val mainActivity = ComponentName(pkg, "$pkg.MainActivity")
        val midnightAlias = ComponentName(pkg, "$pkg.MainActivityMidnight")
        val sunsetAlias = ComponentName(pkg, "$pkg.MainActivitySunset")

        val targetAlias = option.aliasName

        try {
            // Enable target first, then disable others to ensure at least one launcher is active
            when (targetAlias) {
                "com.example.MainActivityMidnight" -> {
                    pm.setComponentEnabledSetting(midnightAlias, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                    pm.setComponentEnabledSetting(mainActivity, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                    pm.setComponentEnabledSetting(sunsetAlias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                }
                "com.example.MainActivitySunset" -> {
                    pm.setComponentEnabledSetting(sunsetAlias, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                    pm.setComponentEnabledSetting(mainActivity, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                    pm.setComponentEnabledSetting(midnightAlias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                }
                else -> {
                    pm.setComponentEnabledSetting(mainActivity, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                    pm.setComponentEnabledSetting(midnightAlias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                    pm.setComponentEnabledSetting(sunsetAlias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                }
            }
        } catch (_: Exception) {
            // Fallback safely if device package manager restricts alias switching
        }
    }
}
