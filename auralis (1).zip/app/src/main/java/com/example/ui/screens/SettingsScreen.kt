package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import com.example.ui.util.AppIconManager
import com.example.ui.util.AppIconOption
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudioQuality
import com.example.data.model.BackgroundStyle
import com.example.data.model.LayoutDensity
import com.example.data.model.PlayerStyle
import com.example.data.model.ThemePreset
import com.example.data.model.UserSettings
import com.example.ui.components.GlassBox
import com.example.ui.components.GlassChip
import com.example.ui.theme.LocalLiquidGlassStyle

@Composable
fun SettingsScreen(
    userSettings: UserSettings,
    onSettingsChange: (UserSettings) -> Unit,
    onOpenEqualizer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val style = LocalLiquidGlassStyle.current
    val context = LocalContext.current
    var ytApiKey by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
    ) {
        // Header
        item {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "Auralis Settings",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                )
                Text(
                    text = "Customize Liquid Glass aesthetics, launcher icon & motion physics",
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                )
            }
            Spacer(modifier = Modifier.height(18.dp))
        }

        // Section: Custom Launcher Icon
        item {
            SettingSectionCard(
                title = "CUSTOM LAUNCHER ICON",
                icon = Icons.Filled.Widgets
            ) {
                Text(
                    text = "Personalize your device home screen icon with futuristic Liquid Glass variants.",
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray
                )
                Spacer(modifier = Modifier.height(12.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AppIconOption.values().forEach { iconOption ->
                        val isSelected = userSettings.appIconName == iconOption.id
                        GlassBox(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    AppIconManager.setAppIcon(context, iconOption)
                                    onSettingsChange(userSettings.copy(appIconName = iconOption.id))
                                },
                            shape = RoundedCornerShape(16.dp),
                            borderWidth = if (isSelected) 1.8.dp else 1.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = iconOption.previewDrawableRes),
                                    contentDescription = iconOption.title,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) style.primaryColor else style.glassBorder,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = iconOption.title,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                                        )
                                        if (isSelected) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(style.primaryColor.copy(alpha = 0.25f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "ACTIVE",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = style.primaryColor
                                                )
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = iconOption.subtitle,
                                        fontSize = 11.sp,
                                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Motion & Fluid Physics
        item {
            SettingSectionCard(
                title = "MOTION & FLUID PHYSICS",
                icon = Icons.Filled.Animation
            ) {
                // Vinyl Disc Rotation
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Holographic Vinyl Disc",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Spinning vinyl record slides out in Now Playing",
                            fontSize = 11.sp,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                        )
                    }
                    Switch(
                        checked = userSettings.vinylRotationEnabled,
                        onCheckedChange = { onSettingsChange(userSettings.copy(vinylRotationEnabled = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = style.primaryColor,
                            checkedTrackColor = style.primaryColor.copy(alpha = 0.35f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 3D Parallax Tilt
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "3D Interactive Gesture Parallax",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Touch and tilt album artwork with spring physics",
                            fontSize = 11.sp,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                        )
                    }
                    Switch(
                        checked = userSettings.parallaxTiltEnabled,
                        onCheckedChange = { onSettingsChange(userSettings.copy(parallaxTiltEnabled = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = style.primaryColor,
                            checkedTrackColor = style.primaryColor.copy(alpha = 0.35f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Atmospheric Fluid Waves
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Liquid Ambient Dynamics",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Organic fluid background wave oscillations",
                            fontSize = 11.sp,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                        )
                    }
                    Switch(
                        checked = userSettings.motionEffectsEnabled,
                        onCheckedChange = { onSettingsChange(userSettings.copy(motionEffectsEnabled = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = style.primaryColor,
                            checkedTrackColor = style.primaryColor.copy(alpha = 0.35f)
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Appearance & Liquid Glass Presets
        item {
            SettingSectionCard(
                title = "LIQUID GLASS PRESETS",
                icon = Icons.Filled.ColorLens
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(ThemePreset.values()) { preset ->
                        val isSelected = userSettings.themePreset == preset
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    onSettingsChange(userSettings.copy(themePreset = preset))
                                }
                                .padding(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(preset.primaryColorHex))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) Color.White else Color.Transparent,
                                        shape = CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = preset.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) style.primaryColor else if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Glass Customization Sliders
        item {
            SettingSectionCard(
                title = "GLASSMORPHISM CONTROLS",
                icon = Icons.Filled.Visibility
            ) {
                // Glass Opacity Slider
                SettingSliderRow(
                    label = "Glass Opacity",
                    value = userSettings.glassOpacity,
                    valueRange = 0.10f..0.70f,
                    displayValue = "${(userSettings.glassOpacity * 100).toInt()}%",
                    onValueChange = { onSettingsChange(userSettings.copy(glassOpacity = it)) }
                )

                // Blur Intensity Slider
                SettingSliderRow(
                    label = "Blur Intensity",
                    value = userSettings.blurIntensity,
                    valueRange = 8f..45f,
                    displayValue = "${userSettings.blurIntensity.toInt()} dp",
                    onValueChange = { onSettingsChange(userSettings.copy(blurIntensity = it)) }
                )

                // Corner Radius Slider
                SettingSliderRow(
                    label = "Corner Radius",
                    value = userSettings.cornerRadiusDp.toFloat(),
                    valueRange = 12f..36f,
                    displayValue = "${userSettings.cornerRadiusDp} dp",
                    onValueChange = { onSettingsChange(userSettings.copy(cornerRadiusDp = it.toInt())) }
                )

                // Animation Intensity Slider
                SettingSliderRow(
                    label = "Animation Fluidity",
                    value = userSettings.animationIntensity,
                    valueRange = 0f..1.5f,
                    displayValue = if (userSettings.animationIntensity <= 0.1f) "Off" else "${(userSettings.animationIntensity * 100).toInt()}%",
                    onValueChange = { onSettingsChange(userSettings.copy(animationIntensity = it)) }
                )

                // Dark Mode Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Dark Liquid Atmosphere",
                        fontSize = 14.sp,
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                    )
                    Switch(
                        checked = userSettings.isDarkMode,
                        onCheckedChange = { onSettingsChange(userSettings.copy(isDarkMode = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = style.primaryColor,
                            checkedTrackColor = style.primaryColor.copy(alpha = 0.35f)
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Background Style
        item {
            SettingSectionCard(
                title = "ATMOSPHERIC BACKGROUND STYLE",
                icon = Icons.Filled.ColorLens
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    BackgroundStyle.values().forEach { bg ->
                        val isSelected = userSettings.backgroundStyle == bg
                        GlassChip(
                            text = bg.title,
                            isSelected = isSelected,
                            onClick = { onSettingsChange(userSettings.copy(backgroundStyle = bg)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Layout & Player Style
        item {
            SettingSectionCard(
                title = "LAYOUT & PLAYER STYLE",
                icon = Icons.Filled.Visibility
            ) {
                Text(
                    text = "Player Presentation",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = style.primaryColor
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PlayerStyle.values().forEach { ps ->
                        GlassChip(
                            text = ps.title,
                            isSelected = userSettings.playerStyle == ps,
                            onClick = { onSettingsChange(userSettings.copy(playerStyle = ps)) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Layout Density",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = style.primaryColor
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LayoutDensity.values().forEach { ld ->
                        GlassChip(
                            text = ld.title,
                            isSelected = userSettings.layoutDensity == ld,
                            onClick = { onSettingsChange(userSettings.copy(layoutDensity = ld)) }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Audio Engine
        item {
            SettingSectionCard(
                title = "AUDIO ENGINE & HARDWARE",
                icon = Icons.Filled.Audiotrack
            ) {
                Text(
                    text = "Preferred Audio Quality Tier",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = style.primaryColor
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AudioQuality.values().forEach { q ->
                        val isSelected = userSettings.audioQuality == q
                        GlassChip(
                            text = "${q.label} • ${q.description}",
                            isSelected = isSelected,
                            onClick = { onSettingsChange(userSettings.copy(audioQuality = q)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Gapless Playback Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Gapless Audio Transitions",
                            fontSize = 14.sp,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Zero silence between continuous tracks",
                            fontSize = 11.sp,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                        )
                    }
                    Switch(
                        checked = userSettings.gaplessPlayback,
                        onCheckedChange = { onSettingsChange(userSettings.copy(gaplessPlayback = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = style.primaryColor)
                    )
                }

                // Audio Focus Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "System Audio Focus",
                            fontSize = 14.sp,
                            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                        )
                        Text(
                            text = "Pause on incoming calls or navigation prompts",
                            fontSize = 11.sp,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                        )
                    }
                    Switch(
                        checked = userSettings.audioFocus,
                        onCheckedChange = { onSettingsChange(userSettings.copy(audioFocus = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = style.primaryColor)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Equalizer Quick Button
                Button(
                    onClick = onOpenEqualizer,
                    colors = ButtonDefaults.buttonColors(containerColor = style.primaryColor.copy(alpha = 0.25f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Filled.Equalizer,
                        contentDescription = null,
                        tint = style.primaryColor
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Open DSP Equalizer & Effects",
                        color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section: Provider & Legal Compliance
        item {
            SettingSectionCard(
                title = "MUSIC PROVIDER & LEGAL COMPLIANCE",
                icon = Icons.Filled.Shield
            ) {
                Text(
                    text = "YouTube Music & Play Policy Standards",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = style.primaryColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Auralis is designed in strict compliance with YouTube Terms of Service and Google Play Developer policies. The app does not scrape private endpoints, bypass DRM, or extract audio from YouTube streams. External streaming runs through open-licensed hi-fi catalogs and official APIs.",
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Optional: Custom YouTube Data API v3 Key",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = ytApiKey,
                    onValueChange = { ytApiKey = it },
                    placeholder = { Text("Enter Google Cloud YouTube Data API Key", fontSize = 12.sp) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = style.primaryColor,
                        unfocusedIndicatorColor = style.glassBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // About
        item {
            SettingSectionCard(
                title = "ABOUT AURALIS",
                icon = Icons.Filled.Info
            ) {
                Text(
                    text = "Auralis v1.0.0 (Audiophile Edition)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (style.isDarkMode) Color.White else Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Engineered with Android Media3, ExoPlayer, Room, Kotlin Coroutines, and Liquid Glass Jetpack Compose design.",
                    fontSize = 12.sp,
                    color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                )
            }
        }
    }
}

@Composable
private fun SettingSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    GlassBox(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = style.primaryColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = style.primaryColor
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SettingSliderRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    displayValue: String,
    onValueChange: (Float) -> Unit
) {
    val style = LocalLiquidGlassStyle.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
            modifier = Modifier.width(115.dp)
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = style.primaryColor,
                activeTrackColor = style.primaryColor,
                inactiveTrackColor = style.glassBorder
            ),
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = displayValue,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = style.primaryColor,
            modifier = Modifier.width(50.dp)
        )
    }
}
