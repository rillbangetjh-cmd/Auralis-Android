package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Track
import com.example.data.provider.SearchFilter
import com.example.data.provider.SearchResult
import com.example.ui.components.AddToPlaylistSheet
import com.example.ui.components.GlassBox
import com.example.ui.components.GlassChip
import com.example.ui.theme.LocalLiquidGlassStyle

@Composable
fun SearchScreen(
    onSearch: suspend (String, SearchFilter) -> SearchResult,
    currentTrack: Track?,
    isPlaying: Boolean,
    onTrackSelect: (Track, List<Track>) -> Unit,
    onPlaylistSelect: (Playlist) -> Unit,
    playlists: List<Playlist>,
    onAddToPlaylist: (Playlist, Track) -> Unit,
    onCreateNewPlaylist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val style = LocalLiquidGlassStyle.current
    var query by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(SearchFilter.ALL) }
    var searchResult by remember { mutableStateOf<SearchResult?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    var trackToAddToPlaylist by remember { mutableStateOf<Track?>(null) }

    LaunchedEffect(query, selectedFilter) {
        isLoading = true
        searchResult = onSearch(query, selectedFilter)
        isLoading = false
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 16.dp)
            .testTag("search_screen")
    ) {
        // Search Header
        Text(
            text = "Explore & Discover",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
            modifier = Modifier.padding(horizontal = 20.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Liquid Glass Search Input
        GlassBox(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            shape = RoundedCornerShape(20.dp),
            borderWidth = 1.2.dp
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = {
                    Text(
                        text = "Search tracks, artists, albums, or FLAC...",
                        color = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray,
                        fontSize = 14.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = style.primaryColor
                    )
                },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = "Clear",
                                tint = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray
                            )
                        }
                    }
                },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = if (style.isDarkMode) Color.White else Color.Black,
                    unfocusedTextColor = if (style.isDarkMode) Color.White else Color.Black
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_input_field")
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Categories Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(SearchFilter.values()) { filter ->
                GlassChip(
                    text = filter.name.replace("_", " "),
                    isSelected = selectedFilter == filter,
                    onClick = { selectedFilter = filter }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = style.primaryColor)
            }
        } else {
            val result = searchResult
            if (result == null || (result.tracks.isEmpty() && result.artists.isEmpty() && result.albums.isEmpty() && result.playlists.isEmpty())) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.MusicNote,
                            contentDescription = null,
                            tint = style.primaryColor.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = if (query.isEmpty()) "Search your local library or legal hi-fi catalog" else "No results found for \"$query\"",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (style.isDarkMode) Color.White.copy(alpha = 0.7f) else Color.DarkGray,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 100.dp)
                ) {
                    // Artists Section
                    if (result.artists.isNotEmpty() && (selectedFilter == SearchFilter.ALL || selectedFilter == SearchFilter.ARTISTS)) {
                        item {
                            Text(
                                text = "ARTISTS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = style.primaryColor,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                items(result.artists) { artist ->
                                    ArtistBubble(artist = artist)
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    // Albums Section
                    if (result.albums.isNotEmpty() && (selectedFilter == SearchFilter.ALL || selectedFilter == SearchFilter.ALBUMS)) {
                        item {
                            Text(
                                text = "ALBUMS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = style.primaryColor,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                            )
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(result.albums) { album ->
                                    AlbumCard(album = album)
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    // Tracks Section
                    if (result.tracks.isNotEmpty() && (selectedFilter == SearchFilter.ALL || selectedFilter == SearchFilter.SONGS)) {
                        item {
                            Text(
                                text = "SONGS (${result.tracks.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = style.primaryColor,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                            )
                        }

                        items(result.tracks) { track ->
                            val isCurrent = currentTrack?.id == track.id
                            TrackListItem(
                                track = track,
                                isCurrent = isCurrent,
                                isPlaying = isCurrent && isPlaying,
                                onClick = { onTrackSelect(track, result.tracks) },
                                trailingAction = {
                                    IconButton(onClick = { trackToAddToPlaylist = track }) {
                                        Icon(
                                            imageVector = Icons.Filled.MoreVert,
                                            contentDescription = "Options",
                                            tint = if (style.isDarkMode) Color.White.copy(alpha = 0.5f) else Color.Gray
                                        )
                                    }
                                },
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    trackToAddToPlaylist?.let { tr ->
        AddToPlaylistSheet(
            track = tr,
            playlists = playlists,
            onSelectPlaylist = { pl ->
                onAddToPlaylist(pl, tr)
                trackToAddToPlaylist = null
            },
            onCreateNewPlaylist = { name ->
                onCreateNewPlaylist(name)
                trackToAddToPlaylist = null
            },
            onDismiss = { trackToAddToPlaylist = null }
        )
    }
}

@Composable
fun ArtistBubble(artist: Artist) {
    val style = LocalLiquidGlassStyle.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(88.dp)
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(style.glassSurface)
        ) {
            if (artist.artworkUri.isNotEmpty()) {
                AsyncImage(
                    model = artist.artworkUri,
                    contentDescription = artist.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    tint = style.primaryColor,
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.Center)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = artist.name,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun AlbumCard(album: Album) {
    val style = LocalLiquidGlassStyle.current
    GlassBox(
        modifier = Modifier.width(130.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                AsyncImage(
                    model = album.artworkUri,
                    contentDescription = album.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = album.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (style.isDarkMode) Color.White else Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = album.artist,
                fontSize = 11.sp,
                color = if (style.isDarkMode) Color.White.copy(alpha = 0.6f) else Color.Gray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
