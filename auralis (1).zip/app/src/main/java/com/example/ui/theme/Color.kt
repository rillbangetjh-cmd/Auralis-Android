package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Liquid Glass Palette Essentials
val DeepVoidDark = Color(0xFF07090E)
val DeepVoidDarkSecondary = Color(0xFF0F1420)
val PureGlassWhite = Color(0xFFFFFFFF)
val TranslucentGlassLight = Color(0x33FFFFFF)
val SubtleGlassBorderLight = Color(0x28FFFFFF)
val SubtleGlassBorderDark = Color(0x1FFFFFFF)

// Presets Accent Colors
// 1. Aurora Glass
val AuroraPrimary = Color(0xFF00F5D4)
val AuroraSecondary = Color(0xFF7B2CBF)
val AuroraAccent = Color(0xFF00BBF9)

// 2. Midnight Glass
val MidnightPrimary = Color(0xFF6366F1)
val MidnightSecondary = Color(0xFF3B82F6)
val MidnightAccent = Color(0xFF818CF8)

// 3. Ocean Glass
val OceanPrimary = Color(0xFF06B6D4)
val OceanSecondary = Color(0xFF0284C7)
val OceanAccent = Color(0xFF38BDF8)

// 4. Sunset Glass
val SunsetPrimary = Color(0xFFFF007A)
val SunsetSecondary = Color(0xFFFF7A00)
val SunsetAccent = Color(0xFFFFD166)

// 5. Mono Glass
val MonoPrimary = Color(0xFFE2E8F0)
val MonoSecondary = Color(0xFF94A3B8)
val MonoAccent = Color(0xFFF1F5F9)

// Audio Quality Colors
val LosslessBadgeBg = Color(0xFF10B981)
val HiResBadgeBg = Color(0xFFF59E0B)
val HqBadgeBg = Color(0xFF6366F1)
val StandardBadgeBg = Color(0xFF64748B)
