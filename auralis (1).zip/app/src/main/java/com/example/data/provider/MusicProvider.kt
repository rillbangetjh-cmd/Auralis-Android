package com.example.data.provider

import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.Playlist
import com.example.data.model.Track

enum class SearchFilter {
    ALL,
    SONGS,
    ARTISTS,
    ALBUMS,
    PLAYLISTS
}

data class SearchResult(
    val query: String,
    val tracks: List<Track> = emptyList(),
    val artists: List<Artist> = emptyList(),
    val albums: List<Album> = emptyList(),
    val playlists: List<Playlist> = emptyList()
)

interface MusicProvider {
    val name: String
    val isAvailable: Boolean

    suspend fun search(query: String, filter: SearchFilter = SearchFilter.ALL): SearchResult
    suspend fun getTrack(id: String): Track?
    suspend fun getArtist(id: String): Artist?
    suspend fun getAlbum(id: String): Album?
    suspend fun getTrendingTracks(): List<Track>
    suspend fun getQuickPicks(mood: String = "All"): List<Track>
    suspend fun getRecommendations(): List<Track>
    suspend fun getFeaturedPlaylists(): List<Playlist>
}
