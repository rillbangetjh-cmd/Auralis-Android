package com.example.data.provider

import android.content.ContentUris
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.AudioQuality
import com.example.data.model.AudioSourceType
import com.example.data.model.Playlist
import com.example.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LocalMusicProvider(private val context: Context) : MusicProvider {

    override val name: String = "Local Audio Storage"
    override val isAvailable: Boolean = true

    override suspend fun search(query: String, filter: SearchFilter): SearchResult = withContext(Dispatchers.IO) {
        val allTracks = scanLocalTracks()
        val q = query.trim().lowercase()

        val filteredTracks = if (q.isEmpty()) allTracks else allTracks.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)
        }

        val artists = filteredTracks.groupBy { it.artist }.map { (artistName, tracks) ->
            Artist(
                id = "artist_${artistName.hashCode()}",
                name = artistName,
                artworkUri = tracks.firstOrNull()?.artworkUri ?: "",
                trackCount = tracks.size
            )
        }

        val albums = filteredTracks.groupBy { it.album to it.artist }.map { (albumPair, tracks) ->
            Album(
                id = "album_${albumPair.first.hashCode()}",
                title = albumPair.first,
                artist = albumPair.second,
                artworkUri = tracks.firstOrNull()?.artworkUri ?: "",
                trackCount = tracks.size
            )
        }

        SearchResult(
            query = query,
            tracks = if (filter == SearchFilter.ALL || filter == SearchFilter.SONGS) filteredTracks else emptyList(),
            artists = if (filter == SearchFilter.ALL || filter == SearchFilter.ARTISTS) artists else emptyList(),
            albums = if (filter == SearchFilter.ALL || filter == SearchFilter.ALBUMS) albums else emptyList(),
            playlists = emptyList()
        )
    }

    override suspend fun getTrack(id: String): Track? = withContext(Dispatchers.IO) {
        scanLocalTracks().find { it.id == id }
    }

    override suspend fun getArtist(id: String): Artist? = withContext(Dispatchers.IO) {
        val all = scanLocalTracks()
        all.groupBy { it.artist }.entries.firstOrNull { "artist_${it.key.hashCode()}" == id }?.let { (artistName, tracks) ->
            Artist(
                id = id,
                name = artistName,
                artworkUri = tracks.firstOrNull()?.artworkUri ?: "",
                trackCount = tracks.size
            )
        }
    }

    override suspend fun getAlbum(id: String): Album? = withContext(Dispatchers.IO) {
        val all = scanLocalTracks()
        all.groupBy { it.album }.entries.firstOrNull { "album_${it.key.hashCode()}" == id }?.let { (albumName, tracks) ->
            Album(
                id = id,
                title = albumName,
                artist = tracks.firstOrNull()?.artist ?: "Unknown Artist",
                artworkUri = tracks.firstOrNull()?.artworkUri ?: "",
                trackCount = tracks.size
            )
        }
    }

    override suspend fun getTrendingTracks(): List<Track> = scanLocalTracks().take(10)

    override suspend fun getQuickPicks(mood: String): List<Track> = scanLocalTracks().shuffled().take(8)

    override suspend fun getRecommendations(): List<Track> = scanLocalTracks().take(12)

    override suspend fun getFeaturedPlaylists(): List<Playlist> = emptyList()

    suspend fun scanLocalTracks(): List<Track> = withContext(Dispatchers.IO) {
        val trackList = mutableListOf<Track>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.YEAR
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 10000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val mimeCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val yearCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val title = it.getString(titleCol) ?: "Unknown Track"
                    val artist = it.getString(artistCol) ?: "Unknown Artist"
                    val album = it.getString(albumCol) ?: "Unknown Album"
                    val duration = it.getLong(durationCol)
                    val albumId = it.getLong(albumIdCol)
                    val mimeType = it.getString(mimeCol) ?: "audio/mpeg"
                    val year = it.getInt(yearCol)

                    val audioUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id).toString()
                    val artworkUri = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"),
                        albumId
                    ).toString()

                    val (codec, quality, bitrate, sampleRate, bitDepth) = inspectAudioFormat(audioUri, mimeType)

                    trackList.add(
                        Track(
                            id = "local_$id",
                            title = title,
                            artist = if (artist.equals("<unknown>", ignoreCase = true)) "Unknown Artist" else artist,
                            album = if (album.equals("<unknown>", ignoreCase = true)) "Unknown Album" else album,
                            durationMs = duration,
                            artworkUri = artworkUri,
                            audioUri = audioUri,
                            sourceType = AudioSourceType.LOCAL,
                            audioQuality = quality,
                            year = if (year > 0) year else 2024,
                            codec = codec,
                            bitrateKbps = bitrate,
                            sampleRateHz = sampleRate,
                            bitDepth = bitDepth
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Permission denied or query error handled safely
        }
        trackList
    }

    private fun inspectAudioFormat(audioUri: String, mimeType: String): AudioFormatInfo {
        var codec = when {
            mimeType.contains("flac", ignoreCase = true) -> "FLAC"
            mimeType.contains("wav", ignoreCase = true) -> "WAV"
            mimeType.contains("mp4", ignoreCase = true) || mimeType.contains("aac", ignoreCase = true) -> "AAC"
            mimeType.contains("ogg", ignoreCase = true) -> "OGG"
            mimeType.contains("alac", ignoreCase = true) -> "ALAC"
            else -> "MP3"
        }
        var sampleRate = 44100
        var bitDepth = 16
        var bitrate = 320

        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, Uri.parse(audioUri))
            val bitrateStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            if (!bitrateStr.isNullOrEmpty()) {
                val b = bitrateStr.toIntOrNull()
                if (b != null && b > 0) bitrate = b / 1000
            }
            if (codec == "FLAC" || codec == "WAV") {
                sampleRate = if (bitrate > 2000) 96000 else 44100
                bitDepth = if (bitrate > 2000) 24 else 16
            }
            retriever.release()
        } catch (_: Exception) {}

        val quality = when {
            codec == "FLAC" && sampleRate >= 96000 -> AudioQuality.HI_RES
            codec == "FLAC" || codec == "WAV" || codec == "ALAC" -> AudioQuality.LOSSLESS
            bitrate >= 256 -> AudioQuality.HIGH
            else -> AudioQuality.STANDARD
        }

        return AudioFormatInfo(codec, quality, bitrate, sampleRate, bitDepth)
    }

    private data class AudioFormatInfo(
        val codec: String,
        val quality: AudioQuality,
        val bitrate: Int,
        val sampleRate: Int,
        val bitDepth: Int
    )
}
