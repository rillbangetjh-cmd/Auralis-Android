package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.local.dao.MusicDao
import com.example.data.local.entity.FavoriteTrackEntity
import com.example.data.local.entity.PlaybackHistoryEntity
import com.example.data.local.entity.PlaylistEntity
import com.example.data.local.entity.PlaylistTrackCrossRef
import com.example.data.local.entity.TrackEntity
import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.AudioQuality
import com.example.data.model.AudioSourceType
import com.example.data.model.BackgroundStyle
import com.example.data.model.EqualizerConfig
import com.example.data.model.LayoutDensity
import com.example.data.model.PlayerStyle
import com.example.data.model.Playlist
import com.example.data.model.ThemePreset
import com.example.data.model.Track
import com.example.data.model.UserSettings
import com.example.data.provider.LegalCatalogMusicProvider
import com.example.data.provider.LocalMusicProvider
import com.example.data.provider.MusicProvider
import com.example.data.provider.SearchFilter
import com.example.data.provider.SearchResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Context.dataStore by preferencesDataStore(name = "auralis_settings")

class MusicRepository(
    private val context: Context,
    private val musicDao: MusicDao,
    private val appScope: CoroutineScope
) {
    val localProvider = LocalMusicProvider(context)
    val catalogProvider = LegalCatalogMusicProvider()

    // Active music providers list
    val providers: List<MusicProvider> = listOf(catalogProvider, localProvider)

    // DataStore keys
    private object Keys {
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val GLASS_OPACITY = floatPreferencesKey("glass_opacity")
        val BLUR_INTENSITY = floatPreferencesKey("blur_intensity")
        val CORNER_RADIUS = intPreferencesKey("corner_radius")
        val BACKGROUND_STYLE = stringPreferencesKey("background_style")
        val IS_DARK_MODE = booleanPreferencesKey("is_dark_mode")
        val ANIMATION_INTENSITY = floatPreferencesKey("animation_intensity")
        val LAYOUT_DENSITY = stringPreferencesKey("layout_density")
        val PLAYER_STYLE = stringPreferencesKey("player_style")
        val AUDIO_QUALITY = stringPreferencesKey("audio_quality")
        val GAPLESS_PLAYBACK = booleanPreferencesKey("gapless_playback")
        val AUDIO_FOCUS = booleanPreferencesKey("audio_focus")
        val SLEEP_TIMER = intPreferencesKey("sleep_timer")
        val APP_ICON = stringPreferencesKey("app_icon")
        val MOTION_ENABLED = booleanPreferencesKey("motion_enabled")
        val VINYL_ROTATION = booleanPreferencesKey("vinyl_rotation")
        val PARALLAX_TILT = booleanPreferencesKey("parallax_tilt")
    }

    private val _userSettings = MutableStateFlow(UserSettings())
    val userSettings: StateFlow<UserSettings> = _userSettings.asStateFlow()

    private val _equalizerConfig = MutableStateFlow(EqualizerConfig())
    val equalizerConfig: StateFlow<EqualizerConfig> = _equalizerConfig.asStateFlow()

    // Favorites
    val favoriteTrackIds: StateFlow<Set<String>> = musicDao.getAllFavoriteTrackIds()
        .map { it.toSet() }
        .stateIn(appScope, SharingStarted.Eagerly, emptySet())

    // Playlists
    val playlists: Flow<List<Playlist>> = musicDao.getAllPlaylists().map { list ->
        list.map {
            Playlist(
                id = it.id,
                name = it.name,
                description = it.description,
                artworkUri = it.artworkUri,
                trackCount = it.trackCount,
                createdAt = it.createdAt
            )
        }
    }

    init {
        loadSettings()
        preloadDefaultData()
    }

    private fun loadSettings() {
        appScope.launch {
            try {
                val prefs = context.dataStore.data.first()
                val themeName = prefs[Keys.THEME_PRESET] ?: ThemePreset.AURORA_GLASS.name
                val theme = runCatching { ThemePreset.valueOf(themeName) }.getOrDefault(ThemePreset.AURORA_GLASS)
                val bgName = prefs[Keys.BACKGROUND_STYLE] ?: BackgroundStyle.DYNAMIC_ARTWORK.name
                val bgStyle = runCatching { BackgroundStyle.valueOf(bgName) }.getOrDefault(BackgroundStyle.DYNAMIC_ARTWORK)
                val densityName = prefs[Keys.LAYOUT_DENSITY] ?: LayoutDensity.COMFORTABLE.name
                val density = runCatching { LayoutDensity.valueOf(densityName) }.getOrDefault(LayoutDensity.COMFORTABLE)
                val playerStyleName = prefs[Keys.PLAYER_STYLE] ?: PlayerStyle.LIQUID_CARD.name
                val playerStyle = runCatching { PlayerStyle.valueOf(playerStyleName) }.getOrDefault(PlayerStyle.LIQUID_CARD)
                val qualityName = prefs[Keys.AUDIO_QUALITY] ?: AudioQuality.HIGH.name
                val quality = runCatching { AudioQuality.valueOf(qualityName) }.getOrDefault(AudioQuality.HIGH)

                _userSettings.value = UserSettings(
                    themePreset = theme,
                    glassOpacity = prefs[Keys.GLASS_OPACITY] ?: 0.28f,
                    blurIntensity = prefs[Keys.BLUR_INTENSITY] ?: 22f,
                    cornerRadiusDp = prefs[Keys.CORNER_RADIUS] ?: 24,
                    backgroundStyle = bgStyle,
                    isDarkMode = prefs[Keys.IS_DARK_MODE] ?: true,
                    animationIntensity = prefs[Keys.ANIMATION_INTENSITY] ?: 1.0f,
                    layoutDensity = density,
                    playerStyle = playerStyle,
                    audioQuality = quality,
                    gaplessPlayback = prefs[Keys.GAPLESS_PLAYBACK] ?: true,
                    audioFocus = prefs[Keys.AUDIO_FOCUS] ?: true,
                    sleepTimerMinutes = prefs[Keys.SLEEP_TIMER] ?: 0,
                    appIconName = prefs[Keys.APP_ICON] ?: "AURORA",
                    motionEffectsEnabled = prefs[Keys.MOTION_ENABLED] ?: true,
                    vinylRotationEnabled = prefs[Keys.VINYL_ROTATION] ?: true,
                    parallaxTiltEnabled = prefs[Keys.PARALLAX_TILT] ?: true
                )
            } catch (_: Exception) {}
        }
    }

    fun updateSettings(newSettings: UserSettings) {
        _userSettings.value = newSettings
        appScope.launch {
            try {
                context.dataStore.edit { prefs ->
                    prefs[Keys.THEME_PRESET] = newSettings.themePreset.name
                    prefs[Keys.GLASS_OPACITY] = newSettings.glassOpacity
                    prefs[Keys.BLUR_INTENSITY] = newSettings.blurIntensity
                    prefs[Keys.CORNER_RADIUS] = newSettings.cornerRadiusDp
                    prefs[Keys.BACKGROUND_STYLE] = newSettings.backgroundStyle.name
                    prefs[Keys.IS_DARK_MODE] = newSettings.isDarkMode
                    prefs[Keys.ANIMATION_INTENSITY] = newSettings.animationIntensity
                    prefs[Keys.LAYOUT_DENSITY] = newSettings.layoutDensity.name
                    prefs[Keys.PLAYER_STYLE] = newSettings.playerStyle.name
                    prefs[Keys.AUDIO_QUALITY] = newSettings.audioQuality.name
                    prefs[Keys.GAPLESS_PLAYBACK] = newSettings.gaplessPlayback
                    prefs[Keys.AUDIO_FOCUS] = newSettings.audioFocus
                    prefs[Keys.SLEEP_TIMER] = newSettings.sleepTimerMinutes
                    prefs[Keys.APP_ICON] = newSettings.appIconName
                    prefs[Keys.MOTION_ENABLED] = newSettings.motionEffectsEnabled
                    prefs[Keys.VINYL_ROTATION] = newSettings.vinylRotationEnabled
                    prefs[Keys.PARALLAX_TILT] = newSettings.parallaxTiltEnabled
                }
            } catch (_: Exception) {}
        }
    }

    fun updateEqualizer(config: EqualizerConfig) {
        _equalizerConfig.value = config
    }

    private fun preloadDefaultData() {
        appScope.launch(Dispatchers.IO) {
            // Seed cached tracks from catalog so they are available offline / in Room
            val catalog = catalogProvider.getTrendingTracks()
            val entities = catalog.map { it.toEntity() }
            musicDao.insertTracks(entities)

            // Seed initial sample playlist if none exists
            val existing = musicDao.getAllPlaylists().first()
            if (existing.isEmpty()) {
                val pId = musicDao.insertPlaylist(
                    PlaylistEntity(
                        name = "Cosmic Vibes",
                        description = "Ambient and futuristic liquid soundscapes",
                        artworkUri = catalog.firstOrNull()?.artworkUri ?: ""
                    )
                )
                catalog.take(4).forEachIndexed { index, track ->
                    musicDao.addTrackToPlaylist(
                        PlaylistTrackCrossRef(
                            playlistId = pId,
                            trackId = track.id,
                            sortOrder = index
                        )
                    )
                }
            }
        }
    }

    // --- Search ---
    suspend fun search(query: String, filter: SearchFilter = SearchFilter.ALL): SearchResult = withContext(Dispatchers.IO) {
        val onlineResult = catalogProvider.search(query, filter)
        val localResult = localProvider.search(query, filter)

        val mergedTracks = (onlineResult.tracks + localResult.tracks).distinctBy { it.id }
        val mergedArtists = (onlineResult.artists + localResult.artists).distinctBy { it.name }
        val mergedAlbums = (onlineResult.albums + localResult.albums).distinctBy { it.title }
        val mergedPlaylists = onlineResult.playlists + localResult.playlists

        SearchResult(
            query = query,
            tracks = mergedTracks,
            artists = mergedArtists,
            albums = mergedAlbums,
            playlists = mergedPlaylists
        )
    }

    // --- Track Discovery ---
    suspend fun getHomeFeed(): HomeFeedData = withContext(Dispatchers.IO) {
        val catalogTracks = catalogProvider.getTrendingTracks()
        val localTracks = localProvider.scanLocalTracks()
        val quickPicks = catalogProvider.getQuickPicks("All")
        val featuredPlaylists = catalogProvider.getFeaturedPlaylists()

        HomeFeedData(
            trending = catalogTracks,
            quickPicks = quickPicks,
            localTracks = localTracks,
            featuredPlaylists = featuredPlaylists
        )
    }

    suspend fun getAllLibraryTracks(): List<Track> = withContext(Dispatchers.IO) {
        val local = localProvider.scanLocalTracks()
        val catalog = catalogProvider.getTrendingTracks()
        (local + catalog).distinctBy { it.id }
    }

    // --- Favorites ---
    suspend fun toggleFavorite(track: Track) = withContext(Dispatchers.IO) {
        // Cache track in DB first
        musicDao.insertTrack(track.toEntity())
        val isFav = favoriteTrackIds.value.contains(track.id)
        if (isFav) {
            musicDao.removeFavorite(track.id)
        } else {
            musicDao.addFavorite(FavoriteTrackEntity(track.id))
        }
    }

    fun isTrackFavorite(trackId: String): Boolean {
        return favoriteTrackIds.value.contains(trackId)
    }

    suspend fun getFavoriteTracks(): List<Track> = withContext(Dispatchers.IO) {
        val favIds = favoriteTrackIds.value
        val all = getAllLibraryTracks()
        all.filter { favIds.contains(it.id) }
    }

    // --- History ---
    suspend fun recordPlayed(track: Track) = withContext(Dispatchers.IO) {
        musicDao.insertTrack(track.toEntity())
        musicDao.insertHistory(
            PlaybackHistoryEntity(
                trackId = track.id,
                title = track.title,
                artist = track.artist,
                album = track.album,
                artworkUri = track.artworkUri
            )
        )
    }

    fun getRecentHistory(): Flow<List<PlaybackHistoryEntity>> = musicDao.getRecentHistory(30)

    // --- Playlists CRUD ---
    suspend fun createPlaylist(name: String, description: String = "", initialTrack: Track? = null): Long = withContext(Dispatchers.IO) {
        val id = musicDao.insertPlaylist(
            PlaylistEntity(
                name = name.trim().ifEmpty { "New Playlist" },
                description = description,
                artworkUri = initialTrack?.artworkUri ?: ""
            )
        )
        if (initialTrack != null) {
            musicDao.insertTrack(initialTrack.toEntity())
            musicDao.addTrackToPlaylist(
                PlaylistTrackCrossRef(
                    playlistId = id,
                    trackId = initialTrack.id,
                    sortOrder = 0
                )
            )
        }
        id
    }

    suspend fun renamePlaylist(id: Long, newName: String, newDescription: String) = withContext(Dispatchers.IO) {
        musicDao.updatePlaylist(id, newName.trim(), newDescription.trim())
    }

    suspend fun deletePlaylist(id: Long) = withContext(Dispatchers.IO) {
        musicDao.deletePlaylist(id)
    }

    suspend fun addTrackToPlaylist(playlistId: Long, track: Track) = withContext(Dispatchers.IO) {
        musicDao.insertTrack(track.toEntity())
        musicDao.addTrackToPlaylist(
            PlaylistTrackCrossRef(
                playlistId = playlistId,
                trackId = track.id,
                sortOrder = (System.currentTimeMillis() % 10000).toInt()
            )
        )
    }

    suspend fun removeTrackFromPlaylist(playlistId: Long, trackId: String) = withContext(Dispatchers.IO) {
        musicDao.removeTrackFromPlaylist(playlistId, trackId)
    }

    fun getPlaylistTracks(playlistId: Long): Flow<List<Track>> {
        return musicDao.getTracksForPlaylist(playlistId).map { entities ->
            entities.map { it.toModel() }
        }
    }

    private fun Track.toEntity() = TrackEntity(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        artworkUri = artworkUri,
        audioUri = audioUri,
        sourceType = sourceType.name,
        audioQuality = audioQuality.name,
        lyrics = lyrics,
        year = year,
        genre = genre,
        bitrateKbps = bitrateKbps,
        sampleRateHz = sampleRateHz,
        bitDepth = bitDepth,
        channelCount = channelCount,
        codec = codec
    )

    private fun TrackEntity.toModel() = Track(
        id = id,
        title = title,
        artist = artist,
        album = album,
        durationMs = durationMs,
        artworkUri = artworkUri,
        audioUri = audioUri,
        sourceType = runCatching { AudioSourceType.valueOf(sourceType) }.getOrDefault(AudioSourceType.STREAMING),
        audioQuality = runCatching { AudioQuality.valueOf(audioQuality) }.getOrDefault(AudioQuality.HIGH),
        lyrics = lyrics,
        year = year,
        genre = genre,
        bitrateKbps = bitrateKbps,
        sampleRateHz = sampleRateHz,
        bitDepth = bitDepth,
        channelCount = channelCount,
        codec = codec,
        isFavorite = favoriteTrackIds.value.contains(id)
    )
}

data class HomeFeedData(
    val trending: List<Track> = emptyList(),
    val quickPicks: List<Track> = emptyList(),
    val localTracks: List<Track> = emptyList(),
    val featuredPlaylists: List<Playlist> = emptyList()
)
