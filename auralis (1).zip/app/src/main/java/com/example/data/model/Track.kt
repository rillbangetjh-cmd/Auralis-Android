package com.example.data.model

enum class AudioSourceType {
    LOCAL,
    STREAMING,
    YOUTUBE_CATALOG
}

enum class AudioQuality(val label: String, val badge: String, val description: String) {
    AUTO("Auto", "AUTO", "Optimized automatically for network & battery"),
    STANDARD("Standard (128 kbps)", "AAC 128k", "AAC / MP3 • Good for mobile data"),
    HIGH("High (320 kbps)", "HQ 320k", "High Bitrate • 320 kbps MP3 / AAC"),
    LOSSLESS("Lossless (CD Quality)", "LOSSLESS", "FLAC / ALAC • 16-bit 44.1 kHz"),
    HI_RES("Hi-Res Audio", "HI-RES", "FLAC • 24-bit 96+ kHz Studio Master")
}

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String = "",
    val durationMs: Long = 0L,
    val artworkUri: String = "",
    val audioUri: String = "",
    val sourceType: AudioSourceType = AudioSourceType.STREAMING,
    val audioQuality: AudioQuality = AudioQuality.HIGH,
    val lyrics: String? = null,
    val year: Int = 2024,
    val genre: String = "Various",
    val bitrateKbps: Int = 320,
    val sampleRateHz: Int = 44100,
    val bitDepth: Int = 16,
    val channelCount: Int = 2,
    val codec: String = "AAC",
    val isFavorite: Boolean = false
) {
    val durationFormatted: String
        get() {
            val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return "%d:%02d".format(minutes, seconds)
        }

    val audioSpecsBadge: String
        get() = "$codec • $bitDepth-bit • ${(sampleRateHz / 1000.0).let { if (it % 1.0 == 0.0) "%.0f".format(it) else "%.1f".format(it) }} kHz"
}

data class Artist(
    val id: String,
    val name: String,
    val artworkUri: String = "",
    val trackCount: Int = 0,
    val bio: String = ""
)

data class Album(
    val id: String,
    val title: String,
    val artist: String,
    val artworkUri: String = "",
    val year: Int = 2024,
    val trackCount: Int = 0
)

data class Playlist(
    val id: Long = 0,
    val name: String,
    val description: String = "",
    val artworkUri: String = "",
    val trackCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

enum class RepeatMode {
    OFF,
    ALL,
    ONE
}
