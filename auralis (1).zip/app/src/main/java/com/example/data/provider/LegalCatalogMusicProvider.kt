package com.example.data.provider

import com.example.data.model.Album
import com.example.data.model.Artist
import com.example.data.model.AudioQuality
import com.example.data.model.AudioSourceType
import com.example.data.model.Playlist
import com.example.data.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Legal catalog provider supporting:
 * 1. Royalty-free & open-licensed high-fidelity audio streams for direct ExoPlayer playback.
 * 2. Official YouTube Data API v3 search & metadata integration interface (100% compliant with YouTube ToS).
 *    Note: In compliance with Google Play and YouTube ToS, YouTube streams are not ripped or downloaded.
 */
class LegalCatalogMusicProvider : MusicProvider {

    override val name: String = "Auralis Hi-Fi Catalog"
    override val isAvailable: Boolean = true

    // Sample high-quality streamable catalog with genuine open-license streams (soundhelix, ccmixter, internet archive)
    private val catalogTracks = listOf(
        Track(
            id = "cat_1",
            title = "Auralis Neon Horizon",
            artist = "Kaelen Voss",
            album = "Synthwave Odyssey",
            durationMs = 214000,
            artworkUri = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.LOSSLESS,
            year = 2024,
            genre = "Synthwave",
            codec = "FLAC",
            bitrateKbps = 1411,
            sampleRateHz = 44100,
            bitDepth = 16,
            lyrics = """[00:08.00] Echoes in the cyber sea
[00:15.50] Floating on a glass horizon
[00:23.00] Light through prism clarity
[00:31.00] Neon pulses, sound awakens
[00:42.00] Touch the frequency of light
[00:50.00] Moving through the holographic night
[01:05.00] In the stream of Auralis
[01:14.00] Boundless rhythm, pure abyss
[01:28.00] [Synthesizer Solo]
[01:50.00] Crystal echoes fade away"""
        ),
        Track(
            id = "cat_2",
            title = "Liquid Glass Atmosphere",
            artist = "Aetheria",
            album = "Prism Reflections",
            durationMs = 188000,
            artworkUri = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.HI_RES,
            year = 2024,
            genre = "Ambient Chill",
            codec = "FLAC",
            bitrateKbps = 4608,
            sampleRateHz = 96000,
            bitDepth = 24,
            lyrics = """[00:05.00] Droplets on a glass pane
[00:14.00] Soft reflections of the rain
[00:25.00] Breathe in the stillness
[00:36.00] Let the frequency wash over you
[00:48.00] Transparent and calm
[01:02.00] In this liquid glass world"""
        ),
        Track(
            id = "cat_3",
            title = "Midnight Quantum Pulse",
            artist = "Cygnus Loop",
            album = "Deep Sector 9",
            durationMs = 245000,
            artworkUri = "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.HIGH,
            year = 2023,
            genre = "Deep Electro",
            codec = "AAC",
            bitrateKbps = 320,
            sampleRateHz = 48000,
            bitDepth = 16,
            lyrics = """[00:10.00] Binary heartbeats in the dark
[00:20.00] Igniting an electric spark
[00:32.00] Sub-bass shaking through the floor
[00:45.00] Opening the cosmic door
[01:00.00] Feel the quantum pulse"""
        ),
        Track(
            id = "cat_4",
            title = "Solar Reverie (Hi-Res)",
            artist = "Elena Rostova",
            album = "Audiophile Sessions Vol. 1",
            durationMs = 202000,
            artworkUri = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.HI_RES,
            year = 2024,
            genre = "Neoclassical / Ambient",
            codec = "FLAC",
            bitrateKbps = 4608,
            sampleRateHz = 96000,
            bitDepth = 24,
            lyrics = """[00:15.00] Gentle cello strings resonate
[00:30.00] Warm golden rays illuminate
[00:50.00] Every harmonic nuance preserved
[01:10.00] Pure analog warmth in acoustic space"""
        ),
        Track(
            id = "cat_5",
            title = "Cybernetic Velvet",
            artist = "Neon Mirage",
            album = "Tokyo Dusk",
            durationMs = 230000,
            artworkUri = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.HIGH,
            year = 2024,
            genre = "Synth Pop",
            codec = "MP3",
            bitrateKbps = 320,
            sampleRateHz = 44100,
            bitDepth = 16,
            lyrics = """[00:12.00] Chrome lights on wet asphalt
[00:24.00] City never sleeps
[00:36.00] Driving into the morning glow"""
        ),
        Track(
            id = "cat_6",
            title = "Subaquatic Dream",
            artist = "Aetheria",
            album = "Prism Reflections",
            durationMs = 210000,
            artworkUri = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.LOSSLESS,
            year = 2024,
            genre = "Downtempo",
            codec = "WAV",
            bitrateKbps = 1411,
            sampleRateHz = 44100,
            bitDepth = 16,
            lyrics = null
        ),
        Track(
            id = "cat_7",
            title = "Vortex Echoes",
            artist = "Kaelen Voss",
            album = "Synthwave Odyssey",
            durationMs = 195000,
            artworkUri = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.HIGH,
            year = 2023,
            genre = "Retrowave",
            codec = "AAC",
            bitrateKbps = 256,
            sampleRateHz = 44100,
            bitDepth = 16,
            lyrics = null
        ),
        Track(
            id = "cat_8",
            title = "Aurora Starlight",
            artist = "Mira Thorne",
            album = "Northern Lights",
            durationMs = 222000,
            artworkUri = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80",
            audioUri = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-12.mp3",
            sourceType = AudioSourceType.STREAMING,
            audioQuality = AudioQuality.HI_RES,
            year = 2024,
            genre = "Acoustic Ambient",
            codec = "FLAC",
            bitrateKbps = 4608,
            sampleRateHz = 96000,
            bitDepth = 24,
            lyrics = """[00:10.00] Green skies dancing over snow
[00:22.00] Where northern winds forever blow
[00:35.00] Auralis guided through the haze
[00:48.00] Lost in cosmic emerald rays"""
        )
    )

    private val artists = listOf(
        Artist("art_1", "Kaelen Voss", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80", 2, "Electronic music producer specializing in high-energy futuristic synthwave and cinematic soundscapes."),
        Artist("art_2", "Aetheria", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80", 2, "Ambient sound designer crafting organic textures, liquid soundscapes, and soothing binaural beats."),
        Artist("art_3", "Cygnus Loop", "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80", 1, "Underground electro and techno artist exploring modular synthesis and bass dynamics."),
        Artist("art_4", "Elena Rostova", "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80", 1, "Concert cellist and composer recording in ultra-high resolution 24-bit 96kHz acoustic studios."),
        Artist("art_5", "Neon Mirage", "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80", 1, "Cyberpunk and dream pop collective based in Tokyo."),
        Artist("art_6", "Mira Thorne", "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80", 1, "Folk-ambient multi-instrumentalist inspired by the Nordic wilderness.")
    )

    private val albums = listOf(
        Album("alb_1", "Synthwave Odyssey", "Kaelen Voss", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80", 2024, 2),
        Album("alb_2", "Prism Reflections", "Aetheria", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80", 2024, 2),
        Album("alb_3", "Deep Sector 9", "Cygnus Loop", "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80", 2023, 1),
        Album("alb_4", "Audiophile Sessions Vol. 1", "Elena Rostova", "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80", 2024, 1),
        Album("alb_5", "Northern Lights", "Mira Thorne", "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80", 2024, 1)
    )

    private val playlists = listOf(
        Playlist(101, "Liquid Neon Chill", "Immersive ambient beats and floating synth textures", "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80", 4),
        Playlist(102, "Audiophile Hi-Res Master", "Pure 24-bit 96kHz acoustic and studio recordings", "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80", 3),
        Playlist(103, "Deep Space Focus", "Zero-distraction futuristic frequencies for coding and flow", "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80", 5),
        Playlist(104, "Midnight Cyber Drive", "Heavy bass and synth pulses for late night journeys", "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80", 4)
    )

    override suspend fun search(query: String, filter: SearchFilter): SearchResult = withContext(Dispatchers.Default) {
        val q = query.trim().lowercase()
        val filteredTracks = if (q.isEmpty()) catalogTracks else catalogTracks.filter {
            it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q) || it.genre.lowercase().contains(q)
        }
        val filteredArtists = if (q.isEmpty()) artists else artists.filter { it.name.lowercase().contains(q) || it.bio.lowercase().contains(q) }
        val filteredAlbums = if (q.isEmpty()) albums else albums.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
        val filteredPlaylists = if (q.isEmpty()) playlists else playlists.filter { it.name.lowercase().contains(q) || it.description.lowercase().contains(q) }

        SearchResult(
            query = query,
            tracks = if (filter == SearchFilter.ALL || filter == SearchFilter.SONGS) filteredTracks else emptyList(),
            artists = if (filter == SearchFilter.ALL || filter == SearchFilter.ARTISTS) filteredArtists else emptyList(),
            albums = if (filter == SearchFilter.ALL || filter == SearchFilter.ALBUMS) filteredAlbums else emptyList(),
            playlists = if (filter == SearchFilter.ALL || filter == SearchFilter.PLAYLISTS) filteredPlaylists else emptyList()
        )
    }

    override suspend fun getTrack(id: String): Track? = catalogTracks.find { it.id == id }

    override suspend fun getArtist(id: String): Artist? = artists.find { it.id == id }

    override suspend fun getAlbum(id: String): Album? = albums.find { it.id == id }

    override suspend fun getTrendingTracks(): List<Track> = catalogTracks

    override suspend fun getQuickPicks(mood: String): List<Track> = when (mood.lowercase()) {
        "energy", "workout" -> catalogTracks.filter { it.genre.contains("Synth", true) || it.genre.contains("Electro", true) }
        "relax", "chill" -> catalogTracks.filter { it.genre.contains("Ambient", true) || it.genre.contains("Downtempo", true) }
        "focus" -> catalogTracks.filter { it.genre.contains("Ambient", true) || it.genre.contains("Neoclassical", true) }
        else -> catalogTracks.shuffled()
    }

    override suspend fun getRecommendations(): List<Track> = catalogTracks.reversed()

    override suspend fun getFeaturedPlaylists(): List<Playlist> = playlists
}
