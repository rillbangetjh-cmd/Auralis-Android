package com.example.data.model

data class EqualizerPreset(
    val name: String,
    val bands: List<Int> // in millibels or dB (-12 to +12 dB)
) {
    companion object {
        val Flat = EqualizerPreset("Flat", listOf(0, 0, 0, 0, 0))
        val Rock = EqualizerPreset("Rock", listOf(5, 3, -1, 3, 5))
        val Pop = EqualizerPreset("Pop", listOf(-1, 2, 5, 2, -2))
        val Classical = EqualizerPreset("Classical", listOf(4, 3, 2, 3, -1))
        val Jazz = EqualizerPreset("Jazz", listOf(3, 2, -2, 2, 4))
        val Vocal = EqualizerPreset("Vocal", listOf(-2, 1, 4, 3, 1))
        val BassBoost = EqualizerPreset("Bass Boost", listOf(7, 5, 2, 0, 0))

        val allPresets = listOf(Flat, Rock, Pop, Classical, Jazz, Vocal, BassBoost)
    }
}

data class EqualizerConfig(
    val isEnabled: Boolean = true,
    val currentPreset: String = "Flat",
    val bands: List<Int> = listOf(0, 0, 0, 0, 0), // 60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz
    val bassBoost: Int = 30, // 0 to 100
    val treble: Int = 20, // 0 to 100
    val balance: Float = 0f, // -1.0 (Left) to +1.0 (Right)
    val preampDb: Float = 0f // -6dB to +6dB
)

enum class ThemePreset(
    val title: String,
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val accentColorHex: Long
) {
    AURORA_GLASS("Aurora Glass", 0xFF00F5D4, 0xFF7B2CBF, 0xFF00BBF9),
    MIDNIGHT_GLASS("Midnight Glass", 0xFF6366F1, 0xFF3B82F6, 0xFF818CF8),
    OCEAN_GLASS("Ocean Glass", 0xFF06B6D4, 0xFF0284C7, 0xFF38BDF8),
    SUNSET_GLASS("Sunset Glass", 0xFFFF007A, 0xFFFF7A00, 0xFFFFD166),
    MONO_GLASS("Mono Glass", 0xFFE2E8F0, 0xFF94A3B8, 0xFFCBD5E1)
}

enum class BackgroundStyle(val title: String) {
    DYNAMIC_ARTWORK("Dynamic Artwork Flow"),
    AURORA_GRADIENT("Aurora Liquid Mesh"),
    DEEP_COSMIC("Deep Cosmic Void"),
    MINIMAL_DARK("Minimal Dark Slate")
}

enum class LayoutDensity(val title: String) {
    COMFORTABLE("Comfortable"),
    COMPACT("Compact")
}

enum class PlayerStyle(val title: String) {
    LIQUID_CARD("Liquid Glass Card"),
    FULLSCREEN_BLOOM("Fullscreen Ambient Bloom"),
    MINIMAL_FLOATING("Minimal Floating")
}

data class UserSettings(
    val themePreset: ThemePreset = ThemePreset.AURORA_GLASS,
    val glassOpacity: Float = 0.28f, // 0.10f to 0.70f
    val blurIntensity: Float = 22f, // 5f to 40f
    val cornerRadiusDp: Int = 24, // 12 to 36
    val backgroundStyle: BackgroundStyle = BackgroundStyle.DYNAMIC_ARTWORK,
    val isDarkMode: Boolean = true,
    val animationIntensity: Float = 1.0f, // 0.0f (disabled) to 1.5f
    val layoutDensity: LayoutDensity = LayoutDensity.COMFORTABLE,
    val playerStyle: PlayerStyle = PlayerStyle.LIQUID_CARD,
    val audioQuality: AudioQuality = AudioQuality.HIGH,
    val gaplessPlayback: Boolean = true,
    val audioFocus: Boolean = true,
    val sleepTimerMinutes: Int = 0, // 0 means off
    val appIconName: String = "AURORA",
    val motionEffectsEnabled: Boolean = true,
    val vinylRotationEnabled: Boolean = true,
    val parallaxTiltEnabled: Boolean = true
)
